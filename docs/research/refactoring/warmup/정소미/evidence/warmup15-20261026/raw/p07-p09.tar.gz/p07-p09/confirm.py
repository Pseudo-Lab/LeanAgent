"""Reproduce the paired fresh-process confirmation and designated-pin checks."""
from pathlib import Path
import json,subprocess,sys
HERE=Path(__file__).resolve().parent
WINNERS={7:'07-injection-and-var',8:'03-par-witness-let'}
def run(pid,name,version,tag):
 path=HERE/'runs'/tag/'result.json'
 if not path.exists():subprocess.run([sys.executable,str(HERE/'evaluate.py'),str(pid),name,version,'3',tag],check=True)
 d=json.loads(path.read_text());assert d['candidate']==name and d['version']==version
 assert all(len(e['runs'])==4 and e['valid'] for e in d['environments'].values()),tag
 assert d['valid'],tag
 return d
for pid in [7,8,9]:
 a=run(pid,'original','v4.32.0',f'P{pid:02}-original-confirm')
 b=run(pid,'current','v4.32.0',f'P{pid:02}-current-confirm')
 if pid in WINNERS:
  c=run(pid,WINNERS[pid],'v4.32.0',f'P{pid:02}-selected-confirm')
  hb=lambda x:x['environments']['v4.32.0']['median_heartbeats']
  score=lambda x:50*(1-x['tokens']/a['tokens'])+50*(1-hb(x)/hb(a))
  assert score(c)>score(b),f'P{pid}: screen win did not reproduce'
  print(json.dumps({'problem':pid,'currentScore':score(b),'selectedScore':score(c),'gain':score(c)-score(b)}),flush=True)
for pid in [7,8]:
 versions=['v4.30.0','v4.31.0','v4.33.0-rc2'] if pid==8 else ['v4.31.0','v4.33.0-rc2']
 for version in versions:
  for name in ['original',WINNERS.get(pid,'current')]:run(pid,name,version,f'P{pid:02}-{name}-{version}-confirm')
print('All paired primary and selected designated-version confirmations passed',flush=True)
