"""Produce the reviewable final summary from saved evidence only."""
from pathlib import Path
import json,hashlib
import refresh_evidence
OUT=Path(__file__).resolve().parent
selection=json.loads((OUT.parent/'starting-selection.json').read_text())
confirmed=json.loads((OUT/'confirmed-summary.json').read_text())
attempts=json.loads((OUT/'attempts.json').read_text())

def info(path):
 file=OUT/path;r=json.loads(file.read_text());result=r['result']
 envs={version:{'valid':env['valid'],'medianHB':env['median_heartbeats'],'scaledRuns':[run['measurement']['scaled'] for run in env['runs'] if 'measurement' in run],'rawRuns':[run['measurement']['raw'] for run in env['runs'] if 'measurement' in run],'logFiles':[str(Path(path).parent/'evaluation'/version/run['log']) for run in env['runs']]} for version,env in result['environments'].items()}
 return {'result':path,'resultSha256':hashlib.sha256(file.read_bytes()).hexdigest(),'proofSha256':r['proofSha256'],'valid':result['valid'],'tokens':result['tokens'],'environments':envs}

rows=[]
for p in selection['problems'][:6]:
 i=p['id'];c=next(r for r in confirmed['problems'] if r['id']==i)
 trials=[]
 for a in attempts['attempts']:
  if a['problem']!=i:continue
  trials.append({'id':a['label'],'sha256':a['sha256'],'result':a.get('receipt'),'valid':a['status']=='passed','status':a['status'],'tokens':a.get('tokens'),'heartbeats':{v:e['median_heartbeats'] for v,e in a.get('environments',{}).items()},'generatedMatchesExecuted':a.get('generatedMatchesExecuted')})
 row={'id':i,'status':c['status'],'starting':{'sha256':p['candidateHash'],'metrics':p['candidate'],'selectedCandidateId':p['selectedCandidateId']},'attempts':trials,'unchangedControls':c.get('excludedUnchangedControls',[]),'selectedProofSha256':c['selectedProofSha256'],'requiredVersions':p['versions']}
 row['finding']={1:'Removing the nil-membership rewrite saves two tokens but increases HB; the equal-weight difference is small.',2:'Retaining an ignored premise changes functional induction obligations. Shorter default rule search passes but costs more HB.',3:'Direct nested update-lemma application passes but is two tokens longer with the same HB.',4:'Typed continuity is longer and more expensive; integral rewriting still needs the correct scalar/Pi multiplication form.',5:'C3 is preserved. Restricting the final algebraic normalization to explicit rules and scalar cancellation substantially reduces HB. A separately verified unused-rule deletion is combined only after both constituents pass.',6:'A normalized helper contract plus direct erw saves tokens but increases HB; explicit finite-list proof obligations reduce HB but add tokens. Neither beats the retained equal-weight candidate.'}[i]
 if 'comparison' in c:
  row['comparison']=c['comparison']|{'originalEvidence':info(f'P{i:02d}/original-confirm3/result.json'),'startingEvidence':info(f'P{i:02d}/starting-confirm3/result.json'),'candidateEvidence':info(str(Path(c.get('selectedProof',f'P{i:02d}/candidate-confirm3/proof.lean')).parent/'result.json'))}
 if 'selectedProof' in c:
  row['winnerProof']=c['selectedProof'];row['versionResults']=[{'version':v,'result':row['comparison']['candidateEvidence']['result'],'status':'pass' if e['valid'] else 'failed'} for v,e in row['comparison']['candidateEvidence']['environments'].items()]
 else:
  row['versionResults']={'status':'starting_candidate_retained','previousEvidence':p['evidence'],'note':'No compatibility improvement claimed; new rejected variants only screened in the prepared primary environment.'}
 rows.append(row)
result={'protocol':confirmed['protocol'],'scope':'actual proof-body optimization of P01–P06, unchanged declarations/full source context and allowed axioms','cost':'No paid API calls; model spend not metered here, so $3 compliance is not claimed.','counts':attempts['counts']|{'distinctAttempts':sum(a['status']!='not_run' for a in attempts['attempts']),'unchangedControls':sum(len(r['unchangedControls']) for r in rows)},'candidateGeneration':{'script':'generate_candidates.py','scriptSha256':hashlib.sha256((OUT/'generate_candidates.py').read_bytes()).hexdigest(),'manifest':'generated/manifest.json','distinctness':'candidate-distinctness.json'},'problems':rows}
(OUT/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'counts':result['counts'],'status':{p['id']:p['status'] for p in rows}},ensure_ascii=False))
