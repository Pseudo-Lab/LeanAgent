"""Audit recorded files and summarize the bounded P07–P09 experiment."""
from pathlib import Path
import hashlib
import json
import statistics

HERE = Path(__file__).resolve().parent
PLAN = json.loads((HERE / 'candidate-plan.json').read_text())['candidates']
WINNERS = {7: '07-injection-and-var', 8: '03-par-witness-let',
           9: json.loads((HERE / 'p09-selection.json').read_text())['selected']}
VERSIONS = {
    7: ['v4.31.0', 'v4.32.0', 'v4.33.0-rc2'],
    8: ['v4.30.0', 'v4.31.0', 'v4.32.0', 'v4.33.0-rc2'],
    9: ['v4.31.0', 'v4.32.0', 'v4.33.0-rc2'],
}
ALLOWED_AXIOMS = {'propext', 'Classical.choice', 'Quot.sound'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(path):
    result = json.loads(path.read_text())
    pid, candidate = result['problemId'], result['candidate']
    proof = HERE / f'P{pid:02}' / f'{candidate}.lean'
    assert sha(proof) == result['candidateHash'], path
    for version, env in result['environments'].items():
        measurements = []
        for run in env['runs']:
            folder = path.parent / version
            assert sha(folder / run['source']) == run['source_sha256'], path
            assert sha(folder / run['log']) == run['log_sha256'], path
            if 'measurement' in run:
                m = run['measurement']
                assert m['scaled'] == m['raw'] // 1000, path
                assert set(m['axioms']) <= ALLOWED_AXIOMS, path
                log = (folder / run['log']).read_text()
                reports = [json.loads(line.split(' ', 2)[2]) for line in log.splitlines()
                           if line.startswith('REFACTOR_EVAL ')]
                assert reports == [m], path
                measurements.append(m['scaled'])
        if env['valid']:
            assert all(run['returncode'] == 0 and not run['timed_out']
                       for run in env['runs']), path
            assert env['median_heartbeats'] == statistics.median(measurements), path
        assert result['fingerprint']['git']['head'] == result['revision'], path
        assert result['fingerprint']['git']['tracked_diff_sha256'] == hashlib.sha256(b'').hexdigest(), path
    return result


def compact(path, expect_three=False):
    result = audit(path)
    env = result['environments'][result['version']]
    if expect_three:
        assert result['valid'] and env['valid'] and len(env['runs']) == 4, path
    return {
        'candidate': result['candidate'], 'candidateSha256': result['candidateHash'],
        'proofPath': f"P{result['problemId']:02}/{result['candidate']}.lean",
        'valid': result['valid'], 'tokens': result['tokens'],
        'medianHeartbeats': env['median_heartbeats'],
        'rawHeartbeats': [r['measurement']['raw'] for r in env['runs'] if 'measurement' in r],
        'scaledHeartbeats': [r['measurement']['scaled'] for r in env['runs'] if 'measurement' in r],
        'axioms': sorted({a for r in env['runs'] if 'measurement' in r for a in r['measurement']['axioms']}),
        'version': result['version'], 'revision': result['revision'],
        'sourceSha256': result['sourceSha256'],
        'templateSha256': result['fingerprint']['template_sha256'],
        'error': env['error'], 'evidence': str(path.relative_to(HERE)),
    }


attempts = []
for entry in PLAN:
    paths = [p for p in (HERE / 'runs').glob('*-screen/result.json')
             if (d := json.loads(p.read_text()))['candidate'] == entry['candidate']
             and d['problemId'] == entry['problemId']]
    assert len(paths) == 1, entry
    row = {**entry, **compact(paths[0])}
    row['attemptId'] = f"P{row['problemId']:02}/{row['candidate']}"
    row['resultPath'] = row['evidence']
    row['selected'] = row['candidate'] == WINNERS[row['problemId']]
    attempts.append(row)
assert len(attempts) == 22
assert len({a['candidateSha256'] for a in attempts}) == len(attempts)
(HERE / 'attempts.json').write_text(json.dumps(attempts, ensure_ascii=False, indent=2) + '\n')

problems = []
for pid in [7, 8, 9]:
    original = compact(HERE / 'runs' / f'P{pid:02}-original-confirm/result.json', True)
    current = compact(HERE / 'runs' / f'P{pid:02}-current-confirm/result.json', True)
    selected = current if WINNERS[pid] == 'current' else compact(HERE / 'runs' / f'P{pid:02}-selected-confirm/result.json', True)
    assert original['sourceSha256'] == current['sourceSha256'] == selected['sourceSha256']
    assert original['templateSha256'] == current['templateSha256'] == selected['templateSha256']

    def score(row):
        return 50 * (1 - row['tokens'] / original['tokens']) + 50 * (1 - row['medianHeartbeats'] / original['medianHeartbeats'])

    compatibility = []
    for version in VERSIONS[pid]:
        if pid == 9 and version != 'v4.32.0':
            if WINNERS[pid] == 'current':
                prior = json.loads((HERE / 'prior-p09-compatibility.json').read_text())
                assert prior['candidateHash'] == selected['candidateSha256']
                evidence = next(v for v in prior['versions'] if v['version'] == version)
                assert evidence['status'] == 'pass' and evidence['repetitions'] == 3
                compatibility.append({**evidence, 'candidateSha256': prior['candidateHash'],
                                      'newRun': False, 'evidence': 'prior-p09-compatibility.json'})
            else:
                chosen = compact(HERE / 'runs' / f'P09-{WINNERS[9]}-{version}-confirm/result.json', True)
                assert chosen['candidateSha256'] == selected['candidateSha256']
                compatibility.append({'version': version, 'selected': chosen, 'newRun': True,
                                      'note': 'Correctness and exact selected proof compatibility; the original was not remeasured on this secondary version.'})
            continue
        if version == 'v4.32.0':
            base, chosen = original, selected
        else:
            base = compact(HERE / 'runs' / f'P{pid:02}-original-{version}-confirm/result.json', True)
            chosen = compact(HERE / 'runs' / f'P{pid:02}-{WINNERS[pid]}-{version}-confirm/result.json', True)
        assert base['sourceSha256'] == chosen['sourceSha256']
        assert base['templateSha256'] == chosen['templateSha256']
        assert chosen['candidateSha256'] == selected['candidateSha256']
        compatibility.append({'version': version, 'original': base, 'selected': chosen, 'newRun': True})
    problems.append({
        'problemId': pid, 'original': original, 'previousBest': current, 'selected': selected,
        'newImprovement': WINNERS[pid] != 'current',
        'previousImprovementScore': score(current), 'selectedImprovementScore': score(selected),
        'gainOverPreviousBestPoints': score(selected) - score(current),
        'compatibility': compatibility,
        'attempted': sum(a['problemId'] == pid for a in attempts),
        'validAttempts': sum(a['problemId'] == pid and a['valid'] for a in attempts),
        'attemptIds': [a['attemptId'] for a in attempts if a['problemId'] == pid],
    })

summary = {
    'schemaVersion': 1,
    'scope': 'P07–P09 bounded proof optimization; no dashboard changes.',
    'protocol': 'lean-source-anchored-v1, frozen PR3 evaluator c18ec56682462847e2f4d8b6d60aa79ec071a10b',
    'selectionRule': 'Maximize the mean of token and heartbeat reduction on v4.32.0, retaining exact proof bytes across all designated versions.',
    'heartbeatUnit': 'floor(raw heartbeat / 1000); confirmation uses median of three fresh Lean measurement processes, plus one pure-context compilation.',
    'scoreFormula': '50 * (1 - candidateTokens / originalTokens) + 50 * (1 - candidateHB / originalHB)',
    'attempted': len(attempts), 'validAttempts': sum(a['valid'] for a in attempts),
    'failedAttempts': sum(not a['valid'] for a in attempts),
    'attempts': attempts,
    'problems': problems,
    'audit': 'Proof, source and log hashes checked; raw/scaled counters and log reports checked; allowed axioms checked; original/current/selected source and template identity checked; exact selected proof hash checked across versions.',
    'paperApplication': {
        'successfulLocalChanges': 'P07 narrows injection-case automation to constructors and closes an impossible variable case; P08 splits parallel-join witness decompositions. The additional P09 trials retain the small existing branch structure and test expected types and explicit successor reuse. Per-problem results determine which changes were selected.',
        'structuralTrials': 'P08 shared S-branch witnesses and recursive join construction, and P09 separated choice/bisimulation obligations, were executed. Some compiled but none beat the current fixed-score best.',
        'limits': 'No complete-development algorithm, coinductive prover, trained policy, or whole-paper system was reproduced. No global optimality or model success-rate claim.',
    },
    'cost': {'paidApiCallsByScripts': 0, 'modelSessionDollarCost': None,
             'note': 'No paid external APIs were invoked. The Codex session bill is unavailable, so a total cost below $3 is not asserted.'},
    'generator': 'generate_candidates.py --baseline <starting-selection.json> --output <directory>',
}
(HERE / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: summary[k] for k in ['attempted', 'validAttempts', 'failedAttempts']}))
for row in problems:
    print(json.dumps({'problem': row['problemId'], 'tokens': row['selected']['tokens'],
                      'HB': row['selected']['medianHeartbeats'], 'gain': row['gainOverPreviousBestPoints'],
                      'versionsPassed': len(row['compatibility'])}))
