theorem bisimilarity_congr_choice :
    (p ~[lts (defs := defs)] q) → (choice p r) ~[lts (defs := defs)] (choice q r) := by
  intro h
  exists ChoiceBisim, ChoiceBisim.choice h
  rintro _ _ (h | h) μ <;> apply (Bisimilarity.isBisimulation _ _ h μ).imp <;> intro f s t <;>
    first
    | exact (f _ t).imp fun _ => And.imp id ChoiceBisim.bisim
    | cases t <;> first
      | exact (f _ ‹_›).imp fun _ => And.imp Tr.choiceL ChoiceBisim.bisim
      | exact ⟨_, Tr.choiceR ‹_›, .bisim (.refl _)⟩
