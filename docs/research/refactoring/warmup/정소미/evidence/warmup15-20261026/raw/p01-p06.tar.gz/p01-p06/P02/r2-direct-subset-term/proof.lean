open OldExpressions in
theorem extractedOldExprInVars :
  NormalizedOldExpr post →
  (extractOldExprVars post).Subset
  (Imperative.HasVarsPure.getVars post) := by
  rintro -
  refine List.Sublist.subset ?_
  fun_induction extractOldExprVars post <;>
    apply_rules only [*, List.nil_sublist, List.Sublist.append, List.Sublist.refl]
