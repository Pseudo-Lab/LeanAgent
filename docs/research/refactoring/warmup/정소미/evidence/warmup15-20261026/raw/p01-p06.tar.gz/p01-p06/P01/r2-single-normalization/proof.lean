open OldExpressions in
theorem substOldPostSubset:
  (Imperative.HasVarsPure.getVars (P:=Expression)
    (substOld h2 (Lambda.LExpr.fvar m h1 ty) post)).Subset
    (Imperative.HasVarsPure.getVars (P:=Expression) post ++ [h1]) := by
  intro x
  fun_induction substOld h2 (Lambda.LExpr.fvar m h1 ty) post <;>
    simp_all only [Imperative.HasVarsPure.getVars, Lambda.LExpr.LExpr.getVars, List.mem_append,
      List.mem_singleton, List.not_mem_nil] <;>
    grind only []
