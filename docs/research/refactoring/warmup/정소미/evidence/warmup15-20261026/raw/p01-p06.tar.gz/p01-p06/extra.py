import execute

def variants():
 p=execute.PROOFS[2]
 yield 2,'r3-default-local-rules',p.replace('apply_rules only [*, ', 'apply_rules [')
 p=execute.PROOFS[3]
 a="  · apply updatedStatesUpdate lu\n    apply updatedStatesDefMonotone\n    exact UpdateStatesDefined' hup"
 b="  · exact updatedStatesUpdate lu (updatedStatesDefMonotone (UpdateStatesDefined' hup))"
 assert a in p
 yield 3,'r2-direct-update-chain-fixed-edit',p.replace(a,b)
 p=next(code for i,label,code in execute.variants() if i==4 and label=='r2-direct-trim-trans')
 yield 4,'r3-repair-trim-direction',p.replace('rw [integral_trim hle', 'rw [← integral_trim hle')
 p=execute.PROOFS[5]
 yield 5,'r3-shared-c3-typed-c2',p.replace('  have hA₂ : ContDiff ℝ 2 A := hA.of_le (by decide)\n  have hA₃ : ContDiff ℝ 3 A := hA.of_le (by decide)','  have hA₃ : ContDiff ℝ 3 A := hA.of_le (by decide)\n  have hA₂ : ContDiff ℝ 2 A := hA₃.of_le (by decide)')
 p=execute.PROOFS[5]
 yield 5,'r4-delete-reported-unused-simp',p.replace('simp only [Pi.sub_apply, sub_right_inj]', 'simp only [sub_right_inj]')
 p=next(code for i,label,code in execute.variants() if i==5 and label=='r2-projections-directed-rewrite')
 yield 5,'r5-repair-under-binder',p.replace('rw [(h t _).1]', 'simp_rw [(h t _).1]')
 p=execute.PROOFS[6]
 yield 6,'r3-explicit-pair-condition',p.replace('(by simp [hφψ, hψφ])','(by simp only [List.forall_mem_cons, List.forall_mem_nil, crAnTimeOrderRel_refl, hφψ, hψφ, and_self])')
 p=execute.PROOFS[6]
 yield 6,'r4-normalize-helper-contract',p.replace('(crAnTimeOrderList (x ++ z ++ y))','(crAnTimeOrderList (x ++ (z ++ y)))').replace('rw [crAnTimeOrderList, insertionSort_of_eq_list','rw [← List.append_assoc, crAnTimeOrderList, insertionSort_of_eq_list').replace('      simp only [List.append_assoc, List.cons_append, List.nil_append] at s v\n','')
if __name__=='__main__':
 for i,label,code in sorted(variants(),key=lambda row:{5:0,6:1,4:2,3:3,2:4}[row[0]]):execute.run(i,label,code)
