"""Execute the five additional P09 candidates through the same serial Lean lane."""
from pathlib import Path
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent
plan = json.loads((HERE / 'candidate-plan.json').read_text())['candidates']
extra = [c for c in plan if c['problemId'] == 9 and int(c['candidate'][:2]) >= 6]
assert len(extra) == 5
for item in extra:
    candidate = item['candidate']
    tag = f'P09-{candidate}-screen'
    if not (HERE / 'runs' / tag / 'result.json').exists():
        subprocess.run([sys.executable, str(HERE / 'evaluate.py'), '9', candidate,
                        'v4.32.0', '1', tag], check=True)
