"""Summarize receipts without generating candidates or invoking Lean."""
from pathlib import Path
import json,hashlib
OUT=Path(__file__).resolve().parent
manifest=json.loads((OUT/'generated/manifest.json').read_text())
rows=[]
for item in manifest['candidates']:
 directory=OUT/f'P{item["problem"]:02d}'/item['label']
 file=directory/'result.json'
 row={**item,'status':'not_run'}
 if file.exists():
  receipt=json.loads(file.read_text());r=receipt['result'];row.update(status='passed' if r['valid'] else 'failed',receipt=str(file.relative_to(OUT)),receiptSha256=hashlib.sha256(file.read_bytes()).hexdigest(),generatedMatchesExecuted=receipt['proofSha256']==item['sha256'],tokens=r['tokens'],environments=r['environments'],error=r['error'])
 rows.append(row)
summary={'selection':'only improvements over frozen strongest selection, equal token/HB weights; final confirmation is separate','attempts':rows,'counts':{status:sum(r['status']==status for r in rows) for status in ['passed','failed','not_run']},'excludedUnchanged':manifest['skippedUnchanged']}
(OUT/'attempts.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
audit=[{'problem':r['problem'],'label':r['label'],'changed':r['sha256']!=r['startingSha256'],'executed':r['status']!='not_run','generatedMatchesExecuted':r.get('generatedMatchesExecuted')} for r in rows]
(OUT/'candidate-distinctness.json').write_text(json.dumps({'candidates':audit,'excludedUnchanged':manifest['skippedUnchanged']},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'counts':summary['counts'],'allExecutedMatch':all(r.get('generatedMatchesExecuted') is not False for r in rows)}))
