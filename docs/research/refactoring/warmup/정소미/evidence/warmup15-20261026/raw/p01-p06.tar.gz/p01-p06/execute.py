from pathlib import Path
import json,hashlib,importlib.util,sys
BASE=Path('/Users/somi/Documents/ChatGPT/가짜연구소_leanagent')
OLD=BASE/'output/2026-10-26-pr-research/all15/strata-physlib'
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('previous_driver',OLD/'run_eval.py');driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver);driver.OUT=OUT
S=json.loads((OUT.parent/'starting-selection.json').read_text())
PROOFS={p['id']:next(c['proof'] for c in p['teamResults'] if c['id']==p['selectedCandidateId']) for p in S['problems'][:6]}
def run(i,label,code,runs=1):
 if (OUT/f'P{i:02d}'/label/'result.json').exists():
  receipt=json.loads((OUT/f'P{i:02d}'/label/'result.json').read_text())
  if receipt['proofSha256'] != hashlib.sha256(code.encode()).hexdigest():raise ValueError(f'Label {label} already records a different proof')
  if receipt['repetitions'] != runs:raise ValueError(f'Label {label} already records a different repetition count')
  return receipt
 return driver.run(i,label,code,runs)
def variants():
 p=PROOFS[1]
 yield 1,'r1-remove-nil-rewrite',p.replace(', List.not_mem_nil','')
 yield 1,'r2-single-normalization',p.replace('  simp only [Imperative.HasVarsPure.getVars, List.mem_append, List.mem_singleton]\n','').replace('simp only [Lambda.LExpr.LExpr.getVars','simp_all only [Imperative.HasVarsPure.getVars, Lambda.LExpr.LExpr.getVars')
 p=PROOFS[2]
 yield 2,'r1-unused-intro',p.replace('rintro -','intro')
 yield 2,'r2-direct-subset-term',p.replace('  apply List.Sublist.subset\n','  refine List.Sublist.subset ?_\n')
 p=PROOFS[3]
 yield 3,'r1-direct-update-chain',p.replace('    apply updatedStatesUpdate lu\n    apply updatedStatesDefMonotone\n    exact UpdateStatesDefined\' hup','    exact updatedStatesUpdate lu (updatedStatesDefMonotone (UpdateStatesDefined\' hup))')
 p=PROOFS[4]
 yield 4,'r1-typed-continuity',p.replace("hf.inner' (𝕜 := ℝ) f (fun _ => f x) continuous_const","(show Continuous (fun y => ⟪f y, f x⟫_ℝ) from hf.inner' _ _ continuous_const)")
 yield 4,'r2-direct-trim-trans',p.replace('(integral_trim hle (hgs.continuous.mul hc).stronglyMeasurable).symm.trans\n      (by simpa only [inner_smul_right\', Pi.mul_apply] using\n        hg _ (.smul_right ⟨hgs, hgc⟩ contDiff_const))',"by\n      rw [integral_trim hle (hgs.continuous.mul hc).stronglyMeasurable]\n      simpa only [inner_smul_right', Pi.mul_apply] using\n        hg _ (.smul_right ⟨hgs, hgc⟩ contDiff_const)")
 p=PROOFS[5]
 yield 5,'r1-derive-c2-from-c3',p.replace('  have hA₂ : ContDiff ℝ 2 A := hA.of_le (by decide)\n  have hA₃ : ContDiff ℝ 3 A := hA.of_le (by decide)','  have hA₃ : ContDiff ℝ 3 A := hA.of_le (by decide)\n  have hA₂ := hA₃.of_le (show (2 : WithTop ℕ∞) ≤ 3 by decide)')
 yield 5,'r2-projections-directed-rewrite',p.replace('simp only [k, (h t _).1, div_eq_inv_mul, Space.deriv_eq_fderiv_basis, fderiv_const_mul','rw [(h t _).1]\n        simp only [k, div_eq_inv_mul, Space.deriv_eq_fderiv_basis, fderiv_const_mul')
 p=PROOFS[6]
 yield 6,'r1-finite-membership-proof',p.replace('(by simp [hφψ, hψφ])','(by simp only [List.mem_cons, List.mem_singleton, forall_eq_or_imp, crAnTimeOrderRel_refl, hφψ, hψφ, and_self, imp_self, forall_const])')
 yield 6,'r2-share-normalized-factorization',p.replace('      simp only [l, r, t, e, ofCrAnListF_append, map_mul, mul_assoc]','      simp only [l, r, t, e, ofCrAnListF_append, map_mul, mul_assoc, List.append_assoc, List.cons_append, List.nil_append]').replace('      simp only [List.append_assoc, List.cons_append, List.nil_append] at s v\n','')
if __name__=='__main__':
 for i,label,code in variants():
  if code == PROOFS[i]:
   print(json.dumps({'id':i,'label':label,'skipped':'unchanged control; not a new candidate'}),flush=True)
   continue
  try:run(i,label,code)
  except Exception as e:print(json.dumps({'id':i,'label':label,'exception':repr(e)}),flush=True)
