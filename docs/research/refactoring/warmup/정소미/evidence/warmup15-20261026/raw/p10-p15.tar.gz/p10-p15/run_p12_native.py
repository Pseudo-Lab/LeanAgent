"""Somi full-source protocol, with a separately named finite-cardinality gate."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = Path('/Users/somi/Documents/ChatGPT/가짜연구소_leanagent/output/2026-10-26-pr-research/all15/arklib-putnam')
sys.path.insert(0, str(OUT.parent / 'cslib/runtime'))
from refactor_eval.tokens import proof_tokens, validate_declaration, without_comments

parser = argparse.ArgumentParser()
parser.add_argument('candidate')
parser.add_argument('--runs', type=int, default=3)
parser.add_argument('--check-only', action='store_true')
parser.add_argument('--tag', help='Separate output label, retaining the exact input candidate')
opts = parser.parse_args()
folder = Path(__file__).resolve().parent / 'P12'
meta = json.loads((folder / 'metadata.json').read_text())
candidate = folder / f'{opts.candidate}.lean'
code = candidate.read_text()
# Gate v2 permits only the existing #( ... ) finite-cardinality notation.
# The source sent to Lean is never changed by this lexical gate.
if re.search(r'#(?!\s*\()', without_comments(code)):
    raise ValueError('Only finite-cardinality #(...) syntax is permitted')
validate_declaration(re.sub(r'#(?=\s*\()', '', code), meta['statement'])
project = OUT / 'arklib-v431'
toolchain = (project / 'lean-toolchain').read_text().strip()
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=project, text=True).strip()
assert toolchain == 'leanprover/lean4:v4.31.0' and revision == meta['sourceRevision']
compiler = '/Users/somi/.elan/toolchains/leanprover--lean4---v4.31.0/bin/lean'
compiler_version = subprocess.check_output([compiler, '--version'], text=True).strip()
source = (project / meta['file_path']).read_text()
start = source.index(meta['statement'])
end = source.index('\nomit ', start)
first = source[:start].count('\n') + 1
last = source[:end].count('\n')
original = source[start:end].rstrip()
assert original == meta['src'].rstrip(), 'Source boundary changed'
checker = OUT.parents[3] / 'LeanAgent/docs/research/refactoring/warmup/정소미/evidence/verify_candidate.py'
output_label = opts.tag or opts.candidate
output = folder / ('screen' if opts.check_only else 'fullsource') / output_label
output.mkdir(parents=True, exist_ok=True)
reports = []
for repeat in range(1, opts.runs + 1):
    tag = f'repeat-{repeat}'
    command = [sys.executable, str(checker), '--repo', str(project), '--file', meta['file_path'],
               '--start', str(first), '--end', str(last), '--name', meta['name'],
               '--statement', str(folder / 'statement.lean'), '--candidate', str(candidate),
               '--workdir', str(output), '--tag', tag, '--extra-import', 'Mathlib.Util.CountHeartbeats',
               '--lean-arg=-j1', '--lean-arg=-M6144', '--timeout', '180']
    if opts.check_only: command.append("--skip-heartbeat")
    completed = subprocess.run(command, text=True, capture_output=True)
    (output / f'{tag}.driver.log').write_text(completed.stdout + completed.stderr)
    report = json.loads((output / f'{tag}.result.json').read_text())
    axiom_text = ' '.join(report['check']['axioms'])
    found = re.findall(r'\[([^\]]*)\]', axiom_text)
    actual = set(re.findall(r'[\w.]+', found[-1])) if found else set()
    allowed = {'propext', 'Classical.choice', 'Quot.sound'}
    report['allowed_axioms_only'] = bool(found) and actual <= allowed
    reports.append(report)
    if not report['compiled']:
        break
result = {'problem': 12, 'candidate': opts.candidate, 'outputLabel': output_label, 'measurementPerformed': not opts.check_only,
          'protocol': 'Somi-full-source-2026-10-05; finite-cardinality-gate-v2',
          'frozenPR3Compatible': False, 'designatedVersion': 'v4.31.0',
          'sourceRevision': meta['sourceRevision'], 'sourceSha256': hashlib.sha256(source.encode()).hexdigest(),
          'environment': {'project': str(project), 'toolchain': toolchain, 'compilerVersion': compiler_version,
                          'manifestSha256': hashlib.sha256((project / 'lake-manifest.json').read_bytes()).hexdigest(),
                          'dependencyPinEvidence': 'arklib-environment.json'},
          'statementSha256': hashlib.sha256(meta['statement'].encode()).hexdigest(),
          'candidateSha256': hashlib.sha256(code.encode()).hexdigest(),
          'tokenizer': 'lean-source-anchored-v1', 'tokens': proof_tokens(code, meta['statement']),
          'heartbeatUnit': 'command-level internal heartbeats divided by 1000 (Mathlib CountHeartbeats)',
          'valid': len(reports) == opts.runs and all(r['statement_unchanged'] and not r['forbidden_patterns'] and
                     r['compiled'] and r['allowed_axioms_only'] and (opts.check_only or r['heartbeat']['heartbeats'] is not None) for r in reports),
          'runs': reports}
(folder / (f'{output_label}.screen.result.json' if opts.check_only else f'{output_label}.fullsource.result.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('problem', 'candidate', 'valid', 'tokens')}))
