"""Confirm a P09 screen winner only after all ten bounded trials have finished."""
from pathlib import Path
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent
plan = json.loads((HERE / 'candidate-plan.json').read_text())['candidates']
current_path = HERE / 'runs/P09-current-confirm/result.json'
original_path = HERE / 'runs/P09-original-confirm/result.json'
current = json.loads(current_path.read_text())
original = json.loads(original_path.read_text())


def score(row):
    return 50 * (1 - row['tokens'] / original['tokens']) + 50 * (
        1 - row['environments']['v4.32.0']['median_heartbeats'] /
        original['environments']['v4.32.0']['median_heartbeats'])


screens = []
for item in plan:
    if item['problemId'] != 9:
        continue
    paths = [p for p in (HERE / 'runs').glob('*-screen/result.json')
             if (d := json.loads(p.read_text()))['problemId'] == 9
             and d['candidate'] == item['candidate']]
    assert len(paths) == 1, item
    result = json.loads(paths[0].read_text())
    if result['valid']:
        screens.append(result)
best = max(screens, key=score)
selected = best['candidate'] if score(best) > score(current) else 'current'
confirmation_paths = []
if selected != 'current':
    for version in ['v4.32.0', 'v4.31.0', 'v4.33.0-rc2']:
        tag = 'P09-selected-confirm' if version == 'v4.32.0' else f'P09-{selected}-{version}-confirm'
        path = HERE / 'runs' / tag / 'result.json'
        if not path.exists():
            subprocess.run([sys.executable, str(HERE / 'evaluate.py'), '9', selected,
                            version, '3', tag], check=True)
        result = json.loads(path.read_text())
        assert result['candidate'] == selected and result['candidateHash'] == best['candidateHash']
        assert result['valid'] and all(e['valid'] and len(e['runs']) == 4 for e in result['environments'].values())
        if version == 'v4.32.0':
            assert score(result) > score(current), 'P09 screen improvement did not reproduce'
        confirmation_paths.append(str(path.relative_to(HERE)))
(HERE / 'p09-selection.json').write_text(json.dumps({
    'selected': selected, 'candidateSha256': best['candidateHash'] if selected != 'current' else current['candidateHash'],
    'screenScore': score(best), 'currentScore': score(current),
    'confirmationPaths': confirmation_paths,
}, indent=2) + '\n')
print(f'P09 selected: {selected}', flush=True)
