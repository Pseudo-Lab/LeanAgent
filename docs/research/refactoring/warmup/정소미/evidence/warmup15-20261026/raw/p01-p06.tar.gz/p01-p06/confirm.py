from pathlib import Path
import json,hashlib
import execute
OUT=Path(__file__).resolve().parent
S=execute.S

def metric(receipt):
 r=receipt['result']
 if not r['valid']:return None
 env=next(iter(r['environments'].values()))
 return {'tokens':r['tokens'],'heartbeats':env['median_heartbeats']} if r['valid'] else None

def score(x,base):return ((1-x['tokens']/base['tokens'])+(1-x['heartbeats']/base['heartbeats']))*50

rows=[]
for p in sorted(S['problems'][:6],key=lambda p:{5:0,6:1,4:2,1:3,2:4,3:5}[p['id']]):
 i=p['id'];receipts=[json.loads(f.read_text()) for f in sorted((OUT/f'P{i:02d}').glob('r*/result.json'))]
 controls=[r for r in receipts if r['proofSha256']==p['candidateHash']]
 receipts=[r for r in receipts if r['proofSha256']!=p['candidateHash']]
 valid=[r for r in receipts if metric(r)]
 improvements=sorted([r for r in valid if score(metric(r),p['baseline'])>score(p['candidate'],p['baseline'])],key=lambda r:score(metric(r),p['baseline']),reverse=True)
 row={'id':i,'startingProofSha256':p['candidateHash'],'startingMetrics':p['candidate'],'attempts':[{k:r[k] for k in ['label','proofSha256','repetitions']}|{'valid':r['result']['valid'],'metrics':metric(r),'evidence':str(Path(f'P{i:02d}')/r['label']/'result.json')} for r in receipts],'status':'no_better_candidate','selectedProofSha256':p['candidateHash'],'excludedUnchangedControls':[r['label'] for r in controls]}
 if improvements:
  original=execute.run(i,'original-confirm3',execute.driver.ROWS[i-1]['src'],3)
  start=execute.run(i,'starting-confirm3',execute.PROOFS[i],3)
  winner=improvements[0];code=(OUT/f'P{i:02d}'/winner['label']/'proof.lean').read_text()
  candidateLabel='candidate-confirm3-'+winner['proofSha256'][:12]
  for existing in sorted((OUT/f'P{i:02d}').glob('candidate-confirm3*/result.json')):
   cached=json.loads(existing.read_text())
   if cached['proofSha256']==winner['proofSha256'] and cached['repetitions']==3:
    candidateLabel=existing.parent.name;break
  after=execute.run(i,candidateLabel,code,3)
  b,old,new=map(metric,[original,start,after]);row['comparison']={'original':b,'before':old,'after':new,'repetitionsEach':3,'chosenScreen':winner['label']}
  if b and old and new:
   delta=score(new,b)-score(old,b);row['comparison']['additionalPoints']=delta
   if delta>0:
    row['status']='primary_improvement_compatibility_pending' if len(p['versions'])>1 else 'improvement_confirmed'
    row['selectedProofSha256']=after['proofSha256'];row['selectedProof']=f'P{i:02d}/{candidateLabel}/proof.lean'
 rows.append(row)
 (OUT/'confirmed-summary.json').write_text(json.dumps({'protocol':'lean-source-anchored-v1; frozen evaluator c18ec56682462847e2f4d8b6d60aa79ec071a10b','problems':rows},ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(row,ensure_ascii=False),flush=True)
