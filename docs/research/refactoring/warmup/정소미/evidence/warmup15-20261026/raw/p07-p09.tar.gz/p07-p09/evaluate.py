"""Reuse frozen PR3 evaluator in the complete pinned source context."""
from pathlib import Path
import argparse, fcntl, hashlib, importlib.util, json, subprocess, sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
OLD=ROOT/'output/2026-10-26-pr-research/all15/cslib'
sys.path.insert(0,str(OLD/'runtime'))
from refactor_eval.lean import LeanEvaluator
spec=importlib.util.spec_from_file_location('warmup_pins',ROOT/'LeanAgent-LeanRefactorArena/scripts/verify_warmup_pins.py')
pins=importlib.util.module_from_spec(spec);spec.loader.exec_module(pins)
p=argparse.ArgumentParser();p.add_argument('problem',type=int);p.add_argument('candidate');p.add_argument('version');p.add_argument('runs',type=int);p.add_argument('tag');a=p.parse_args()
meta=[json.loads(l) for l in (OLD/'benchmark.jsonl').read_text().splitlines() if l.strip()][a.problem-1]
name={'v4.32.0':'cslib','v4.31.0':'cslib-v4.31.0','v4.33.0-rc2':'cslib-v4.33.0-rc2','v4.30.0':'cslib-v4.30.0'}[a.version]
project=(OLD/'environments'/name) if a.version=='v4.30.0' else Path('/Users/somi/Documents/lean-refactor-warmup')/name
revision=next(v[a.version] for v in meta['version_info'] if a.version in v)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=project,text=True).strip()==revision
source=(project/meta['file_path']).read_text();template,lead=pins.template(meta,source)
env={'id':a.version,'project':str(project),'toolchain':f'leanprover/lean4:{a.version}','command':['lake','env','lean','-j1','-M6144','-T200000'],'template':template,'timeout_seconds':180,'fingerprint_files':[meta['file_path']]}
lock=(OLD/'lane.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX)
code=(HERE/f'P{a.problem:02}'/f'{a.candidate}.lean').read_text();e=LeanEvaluator();out=HERE/'runs'/a.tag;out.parent.mkdir(exist_ok=True)
fingerprint=e.fingerprint(env);result=e.evaluate(lead+code,{'statement':lead+meta['statement'],'name':meta['name']},[env],out,a.runs)
result.update(problemId=a.problem,candidate=a.candidate,version=a.version,revision=revision,candidateHash=hashlib.sha256(code.encode()).hexdigest(),fingerprint=fingerprint,sourceSha256=hashlib.sha256(source.encode()).hexdigest(),evaluatorRevision='c18ec56682462847e2f4d8b6d60aa79ec071a10b',protocol='lean-source-anchored-v1 frozen PR3 evaluator')
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'tag':a.tag,'valid':result['valid'],'tokens':result['tokens'],'environments':{k:{'valid':v['valid'],'HB':v['median_heartbeats'],'error':v['error']} for k,v in result['environments'].items()}},ensure_ascii=False),flush=True)
