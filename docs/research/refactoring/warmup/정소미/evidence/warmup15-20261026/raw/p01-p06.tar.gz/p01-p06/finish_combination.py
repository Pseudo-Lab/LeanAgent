"""Select the final P05 composition only after its completed three-run receipt."""
from pathlib import Path
import json
O=Path(__file__).resolve().parent
f=O/'P05/r9-combine-verified-pruning/result.json'
r=json.loads(f.read_text());assert r['repetitions']==3
summary=json.loads((O/'confirmed-summary.json').read_text())
p=next(p for p in summary['problems'] if p['id']==5)
if r['result']['valid']:
 env=next(iter(r['result']['environments'].values()))
 assert len([x for x in env['runs'] if 'measurement' in x])==3
 c=p['comparison'];after={'tokens':r['result']['tokens'],'heartbeats':env['median_heartbeats']}
 def score(m):return 50*(2-m['tokens']/c['original']['tokens']-m['heartbeats']/c['original']['heartbeats'])
 if score(after)>score(c['after']):
  c.update(after=after,chosenScreen=r['label'],additionalPoints=score(after)-score(c['before']))
  p.update(selectedProofSha256=r['proofSha256'],selectedProof='P05/r9-combine-verified-pruning/proof.lean')
(O/'confirmed-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
import finalize
