from pathlib import Path
p=Path(__file__).parent/"P12"
s=(p/"snoc-direct.lean").read_text()
s=s.replace("simp_rw [Fin.snoc_init_self] at h_split", "simp_rw [← Fin.init_def, Fin.snoc_init_self] at h_split")
(p/"snoc-init-fold.lean").write_text(s)
