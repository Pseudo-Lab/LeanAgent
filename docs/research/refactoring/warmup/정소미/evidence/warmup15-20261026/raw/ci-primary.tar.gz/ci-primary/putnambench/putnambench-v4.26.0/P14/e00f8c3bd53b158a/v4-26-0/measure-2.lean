import Lean
import Mathlib
import Aesop

open Lean Elab Command in
elab "#refactor_eval " tag:str target:str cmd:command : command =>
  show CommandElabM Unit from do
    let name := target.getString.toName
    if (← getEnv).contains name then
      throwError "evaluation target already exists before candidate"
    let start ← IO.getNumHeartbeats
    elabCommand cmd
    let finish ← IO.getNumHeartbeats
    let env ← getEnv
    unless env.contains name do
      throwError "candidate did not define evaluation target"
    let axioms ← Lean.collectAxioms name
    let report := Json.mkObj [
      ("target", toJson target.getString),
      ("raw", toJson (finish - start)),
      ("scaled", toJson ((finish - start) / 1000)),
      ("axioms", toJson (axioms.toList.map Name.toString))]
    logInfo m!"REFACTOR_EVAL {tag.getString} {report.compress}"


set_option maxHeartbeats 0

open Set Function Filter Topology


set_option Elab.async false in
#refactor_eval "297e0382c92b4de293f42164d74647c4" "putnam_1964_b2"
theorem putnam_1964_b2
(S : Type*) [Fintype S] [Nonempty S]
(P : Finset (Set S))
(hPP : ∀ T ∈ P, ∀ U ∈ P, T ∩ U ≠ ∅)
(hPS : ¬∃ T : Set S, T ∉ P ∧ (∀ U ∈ P, T ∩ U ≠ ∅))
: (P.card = 2 ^ (Fintype.card S - 1)) := by
  classical
  have hP : (P : Set (Set S)).Intersecting := by
    simpa [Set.Intersecting, Set.disjoint_iff_inter_eq_empty] using hPP
  have hcard := hP.is_max_iff_card_eq.mp (by
    intro Q hQ hPQ
    apply Finset.Subset.antisymm hPQ
    intro T hT
    by_contra hT'
    exact hPS ⟨T, hT', fun U hU => by
      simpa [Set.disjoint_iff_inter_eq_empty] using hQ hT (hPQ hU)⟩)
  rw [Fintype.card_set] at hcard
  have hn := Fintype.card_pos (α := S)
  rw [show Fintype.card S = (Fintype.card S - 1) + 1 by omega, pow_succ] at hcard
  omega

