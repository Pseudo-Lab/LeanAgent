"""Bounded follow-up: eliminate repeated normalization and target algebra-only blocks."""
import execute,extra

def variants():
 p=execute.PROOFS[5]
 yield 5,'r6-simp-small-coefficient',p.replace('        ring1','        simp [pow_two, mul_assoc, mul_left_comm, mul_comm]')
 yield 5,'r7-restrict-final-normalization',p.replace('          simp [k, div_eq_mul_inv, pow_two,\n            mul_assoc, mul_left_comm, mul_comm]','          simp only [k, div_eq_mul_inv, pow_two, mul_inv_rev, one_mul,\n            mul_assoc, mul_left_comm, mul_comm, inv_mul_cancel_left₀ 𝓕.μ₀_ne_zero]')
 p=next(code for i,label,code in extra.variants() if i==6 and label=='r4-normalize-helper-contract')
 a='      have s := f [φ, ψ] (by simp [hφψ, hψφ])\n      have v := f [ψ, φ] (by simp [hφψ, hψφ])\n      rw [s, v, smul_sub, smul_comm]'
 b='      erw [f [φ, ψ] (by simp [hφψ, hψφ]), f [ψ, φ] (by simp [hφψ, hψφ]),\n        smul_sub, smul_comm]'
 assert a in p
 yield 6,'r5-inline-shared-helper-uses',p.replace(a,b).replace('simp only [List.append_nil, ofCrAnListF_nil','simp only [List.nil_append, ofCrAnListF_nil')
 p=execute.PROOFS[6]
 yield 6,'r6-close-empty-predicate-directly',p.replace('(by simp [hφψ, hψφ])','(by simp only [List.forall_mem_cons, crAnTimeOrderRel_refl, hφψ, hψφ, true_and]; exact List.forall_mem_nil _)')
 p=execute.PROOFS[5]
 p8=p.replace('          simp [k, div_eq_mul_inv, pow_two,\n            mul_assoc, mul_left_comm, mul_comm]','          simp only [k, div_eq_mul_inv, pow_two, mul_inv_rev, one_mul,\n            mul_assoc, mul_left_comm, mul_comm]\n          rw [mul_left_comm 𝓕.μ₀, mul_inv_cancel_left₀ 𝓕.μ₀_ne_zero]')
 yield 5,'r8-repair-scalar-cancellation',p8
 yield 5,'r9-combine-verified-pruning',p8.replace('simp only [Pi.sub_apply, sub_right_inj]', 'simp only [sub_right_inj]')
if __name__=='__main__':
 for i,label,code in variants():execute.run(i,label,code)
