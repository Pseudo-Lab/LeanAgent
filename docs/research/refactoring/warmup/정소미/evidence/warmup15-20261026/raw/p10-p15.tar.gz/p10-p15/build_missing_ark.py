"""Bounded local compilation of missing transitive imports only, no Lake build graph."""
from pathlib import Path
import json,os,re,signal,subprocess,time
# Resolve relative to the workspace output directory.
ROOT=Path(__file__).resolve().parents[2]/'2026-10-26-pr-research/all15/arklib-putnam/arklib-v431'
OUT=Path(__file__).resolve().parent/'ark-targeted-build';OUT.mkdir(exist_ok=True)
roots=[ROOT,*list((ROOT/'.lake/packages').iterdir())]
seen=set();plan=[]
def visit(module):
 if module in seen:return
 seen.add(module);relative=Path(*module.split('.'))
 p=next((p for p in roots if (p/relative.with_suffix('.lean')).is_file()),None)
 if p is None:raise ValueError('Missing source '+module)
 dest=p/'.lake/build/lib/lean'/relative.with_suffix('.olean')
 if dest.exists():return
 if p!=ROOT:raise ValueError('Refusing dependency package rebuild '+module)
 src=p/relative.with_suffix('.lean')
 for dep in re.findall(r'(?m)^(?:public )?import\s+(\S+)',src.read_text()):visit(dep)
 plan.append((module,src,dest))
for target in ['ArkLib.ProofSystem.Sumcheck.Spec.SingleRound','ArkLib.ProofSystem.Sumcheck.Structured.SingleRound']:visit(target)
assert len(plan)<=20
(OUT/'plan.json').write_text(json.dumps([{'module':m,'source':str(s),'output':str(d)} for m,s,d in plan],indent=2)+'\n')
started=time.monotonic();rows=[]
for index,(module,source,dest) in enumerate(plan):
 remaining=480-(time.monotonic()-started)
 if remaining<=0:break
 dest.parent.mkdir(parents=True,exist_ok=True)
 command=['lake','env','lean','-j1','-M6144','-o',str(dest),str(source)]
 log=OUT/f'{index+1:02d}-{module}.log'
 begin=time.monotonic();timeout=False
 with log.open('w') as handle:
  child=subprocess.Popen(command,cwd=ROOT,stdout=handle,stderr=subprocess.STDOUT,env=dict(os.environ,LEAN_NUM_THREADS='1'),start_new_session=True)
  (OUT/'active.json').write_text(json.dumps({'pid':child.pid,'module':module,'started':begin,'deadline':started+480})+'\n')
  try:rc=child.wait(timeout=remaining)
  except subprocess.TimeoutExpired:
   timeout=True;os.killpg(child.pid,signal.SIGTERM)
   try:rc=child.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);rc=child.wait()
 row={'module':module,'returncode':rc,'timeout':timeout,'seconds':time.monotonic()-begin,'log':str(log),'oleanCreated':dest.exists()}
 rows.append(row);(OUT/'result.json').write_text(json.dumps({'planned':len(plan),'completed':len(rows),'runs':rows},indent=2)+'\n');print(json.dumps(row),flush=True)
 if rc or timeout:break
print(json.dumps({'planned':len(plan),'completed':len(rows),'seconds':time.monotonic()-started}),flush=True)
