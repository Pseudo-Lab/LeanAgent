/-
Copyright (c) 2024 - 2025 ArkLib Contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Chung Thai Nguyen, Quang Dao
-/

import ArkLib.Data.CodingTheory.ProximityGap.DG25.Basic

/-!
# DG25 Main Interleaved-Code Results

This module contains the main interleaved and tensor proximity-gap lemmas from the DG25
formalization, up to the generic tensor-gap lifting theorem.
-/

noncomputable section

open Code LinearCode InterleavedCode ReedSolomon ProximityGap ProbabilityTheory Filter
open NNReal Finset Function Real
open scoped BigOperators LinearCode ProbabilityTheory

universe u v w k l
variable {κ : Type k} {ι : Type l} [Fintype ι] [Nonempty ι] [DecidableEq ι] [DecidableEq κ]
variable {F : Type v} [Semiring F] [Fintype F]
variable {A : Type w} [Fintype A] [DecidableEq A] [AddCommMonoid A] [Module F A]
section MainResults
variable {F : Type} [CommRing F] [Fintype F] [NoZeroDivisors F] [DecidableEq F]
  -- switch to Type for `Pr_{...}[...]` usage
  {A : Type} [Fintype A] [DecidableEq A] [AddCommGroup A] [Module F A] [Module.Free F A]
  -- Semiring.toModule (R := A) => Module A A, plus Ring A for `RS code` theorems?
variable (MC : ModuleCode ι F A) [Nontrivial MC]
  (C : Set (Word A ι)) [Nonempty C] -- todo: change to Nontrivial if needed

instance : Nonempty MC := by exact instNonemptyOfInhabited

-- instance : ∀ (κ : Type*) [Fintype κ] [DecidableEq κ], Nonempty (C ^⋈ κ) := by
--   intro κ hκ hκ_dec
--   exact instNonemptyInterleavedCode A (κ := κ) (ι := ι) C

/-!
## Section 3: Main Results
-/

variable {m : Nat} -- Interleaving factor > 0 (Proof uses m>1 later)
variable {e ε : ℕ} -- Proximity parameter and false witness bound

/-- The set R* of parameters `r` for which `Uᵣ` is e-close to the interleaved code C^m
i.e. `R* := {r ∈ F | d^m(Uᵣ, C^m) ≤ e}` -/
def R_star (U₀ U₁ : InterleavedWord A (Fin m) ι) : Finset F :=
  Finset.filter (fun r : F =>
    Δ₀(affineLineEvaluation (F := F) (u₀ := U₀) (u₁ := U₁) r, C ^⋈ (Fin m)) ≤ e
  ) Finset.univ

open Classical in
/-- The set D = Δ^{2m}(U, V), columns where U₀≠V₀ or U₁≠V₁. -/
def disagreementSet (U₀ U₁ V₀ V₁ : InterleavedWord A (κ := κ) (ι := ι)) : Finset ι :=
  Finset.filter (fun colIdx => (U₀ colIdx ≠ V₀ colIdx) ∨ (U₁ colIdx ≠ V₁ colIdx)) Finset.univ

/-- The set `R** = {(r, j) ∈ R* × {0..n-1} | (Uᵣ)ʲ = (Vᵣ)ʲ}.` -/
def R_star_star (U₀ U₁ V₀ V₁ : InterleavedWord A (Fin m) ι) : Finset (F × ι) :=
  (R_star C (m := m) (e := e) U₀ U₁) ×ˢ (Finset.univ (α := ι)) |>.filter (fun (r, j) =>
    let Uᵣ := affineLineEvaluation U₀ U₁ r
    let Vᵣ := affineLineEvaluation V₀ V₁ r
    Uᵣ j = Vᵣ j)

omit [Nonempty ι] [DecidableEq ι] [DecidableEq κ] [Fintype A] [AddCommGroup A] in
/-- Row-wise distance is bounded by interleaved distance.
i.e. `d((U)ᵢ, (M)ᵢ) ≤ d^m(U, M)` -/
lemma dist_row_le_dist_ToInterleavedWord (U : InterleavedWord A (κ := κ) (ι := ι))
    (M : InterleavedWord A (κ := κ) (ι := ι)) (rowIdx : κ)
    [DecidableEq (κ → A)] :
    Δ₀(getRow U rowIdx, getRow M rowIdx) ≤ Δ₀(U, M) := by
  apply Finset.card_le_card
  refine monotone_filter_right univ ?_
  exact fun a a_1 a_2 ↦ mt (congrArg fun a ↦ a rowIdx) a_2

omit [AddCommGroup A] [Fintype F] [Nonempty ι] [DecidableEq ι] [Fintype A]
  [NoZeroDivisors F] [DecidableEq F] [Module.Free F A] in
/-- Helper Lemma relating row distance to interleaved distance (as derived from DG25):
  `d((Uᵣ)ᵢ, C) ≤ d^m(Uᵣ, C^m)` -/
lemma dist_row_le_dist_ToInterleavedCode (U : InterleavedWord A (Fin m) ι) :
    ∀ (rowIdx : Fin m), Δ₀((getRow U rowIdx), C) ≤ Δ₀(U, C ^⋈ (Fin m)) := by
  intro i
  let d_To_interleaved := Code.distFromCode (u := U) (C := C ^⋈ (Fin m))
  -- There exists M achieving this distance e_int
  have h_exists : ∃ M ∈ C ^⋈ (Fin m), Δ₀(U, M) = d_To_interleaved :=
    @Code.exists_closest_codeword_of_Nonempty_Code _ _ _ _
      (C ^⋈ (Fin m)) (instNonemptyInterleavedCode (κ := Fin m) (C := C)) U
  rcases h_exists with ⟨M, hM_mem, hM_dist⟩
  let Uᵢ := getRow U i
  let iM : InterleavedCodeword (A := A) (κ := Fin m) (ι := ι) (C := C):= ⟨M, hM_mem⟩
  let Mᵢ : C := getRow iM i
  -- InterleavedCodeword.getRowCodeword (A := A) (κ := Fin m) (ι := ι) (C := C) (v := iM) i
  -- We know d(Uᵢ, C) ≤ d(Uᵢ, Mᵢ) because Mᵢ ∈ C (from h_rows M hM_mem i)
  have dist_le_dist : Δ₀(Uᵢ, C) ≤ Δ₀(Uᵢ, Mᵢ) := by
    apply csInf_le' -- Using sInf property
    --  ⊢ ↑Δ₀(Uᵢ, Mᵢ) ∈ {d | ∃ v ∈ ↑MC, ↑Δ₀(Uᵢ, v) ≤ d}
    simp only [Set.mem_setOf_eq, Nat.cast_le]
    -- ⊢ ∃ v ∈ C, Δ₀(Uᵢ, v) ≤ Δ₀(Uᵢ, Mᵢ)
    use Mᵢ
    simp only [Subtype.coe_prop, le_refl, and_self]
  apply le_trans dist_le_dist
  -- ⊢ ↑Δ₀(Uᵢ, ↑Mᵢ) ≤ Δ₀(U, ↑C_m)
  have h_dist_row_le_dist_interleaved : Δ₀(Uᵢ, Mᵢ) ≤ Δ₀(U, M) := by
    change Δ₀(getRow U i, getRow M i) ≤ Δ₀(U, M)
    exact dist_row_le_dist_ToInterleavedWord U M i
  calc
    (Δ₀(Uᵢ, Mᵢ): ℕ∞) ≤ (Δ₀(U, M): ℕ∞) :=
      ENat.coe_le_coe.mpr h_dist_row_le_dist_interleaved
    _ ≤ Δ₀(U, C ^⋈ (Fin m)) := le_of_eq hM_dist

/-- Extracts the constructed codewords V₀, V₁ and their agreement properties.
Hypotheses: 1. more than ε affine combinations Uᵣ are close to C^m (`hR_star_card`),
2. the base code C features proximity gaps for affine lines (`hC_gap`)
=> This function constructs the corresponding `interleaved codewords` `V₀` and `V₁` in `C^m`
that exhibit correlated agreement with `U₀` and `U₁` row-by-row respectively.
It returns a tuple containing:
- `V₀`, `V₁` : Codewords in `C^m`
- `hRowWise_pair_CA`: `Δ₀((u₀ := getRow U₀ rowIdx) ⋈₂ (u₁ := getRow U₁ rowIdx),`
                          `(v₀ := getRow V₀ rowIdx) ⋈₂ (v₁ := getRow V₁ rowIdx)) ≤ e`
-/
def constructInterleavedCodewordsAndRowWiseCA
    (U₀ U₁ : InterleavedWord A (Fin m) ι)
  (hC_gap : e_ε_correlatedAgreementAffineLinesNat (F := F) (C := C) e ε)
  (hR_star_card : (R_star (F := F) (C := C) (m := m) (e := e) U₀ U₁).card > ε) :
  Σ' (V₀ V₁ : C ^⋈ (Fin m)), -- Σ' creates a dependent tuple
    ∀ rowIdx, pairJointProximity₂ (u₀ := getRow U₀ rowIdx)
      (u₁ := getRow U₁ rowIdx)
      (v₀ := getRow (show (InterleavedCodeword A (Fin m) ι C) from V₀) rowIdx)
      (v₁ := getRow (show (InterleavedCodeword A (Fin m) ι C) from V₁) rowIdx) e := by
  let V₀₁ : (rowIdx: Fin m)
    → Σ' (v₀ v₁ : C), pairJointProximity₂ (u₀ := getRow U₀ rowIdx)
    (u₁ := getRow U₁ rowIdx) (v₀ := v₀) (v₁ := v₁) e := fun rowIdx => by
    set u₀ := getRow U₀ rowIdx
    set u₁ := getRow U₁ rowIdx
    -- Need: Δ₀(u₀ ⋈₂ u₁, v₀ ⋈₂ v₁) ≤ e, this requires { r | (1 - r) • u₀ + r • u₁ ∈ C} > ε,
      -- which can be derived from hR_star_card
    -- For any row i, R_star_card implies the proximity gap property applies to that row
    have h_P_affineCombineRow:
      (Pr_{ let r ←$ᵖ F }[ -- Probability notation
        (Δ₀(affineLineEvaluation (F := F) u₀ u₁ r, C) ≤ e: Prop)
      ] > ((ε: ℝ≥0) / (Fintype.card F : ℝ≥0))) := by
      -- Goal: Show probability > ε / q
      -- We know: card R* > ε, where R* = {r | Δ₀(Uᵣ, C^m) ≤ e}
      -- Let R_line = {r | Δ₀((Uᵣ)ᵢ, C) ≤ e}
      -- We proved earlier: R* ⊆ R_line
      -- So, card R_line ≥ card R* > ε
      let R_star_set := R_star (F := F) (C := C) (m := m) (e := e) U₀ U₁
      let R_line_set := Finset.filter (fun r =>
          Δ₀(affineLineEvaluation (F := F) u₀ u₁ r, C) ≤ e) Finset.univ
      -- Prove R* ⊆ R_line
      have R_star_subset : R_star_set ⊆ R_line_set := by
        intro r hr_mem
        simp only [R_star, mem_filter, mem_univ, true_and, R_star_set] at hr_mem
        simp only [R_line_set, Finset.mem_filter, Finset.mem_univ, true_and]
        -- Use dist_row_le_dist_ToInterleavedCode
        let Uᵣ : InterleavedWord A (Fin m) ι := affineLineEvaluation U₀ U₁ r
        have h_dist_le := dist_row_le_dist_ToInterleavedCode C Uᵣ rowIdx
        have h_row_eq : affineLineEvaluation u₀ u₁ r = getRow Uᵣ rowIdx := by
          ext j;
          simp only [affineLineEvaluation, Word, Pi.add_apply, Pi.smul_apply, getRow,
            InterleavedWord.getRowWord, Matrix.transpose_apply, Uᵣ]
          have h_u₀_j : u₀ j = U₀ j rowIdx := by rfl
          have h_u₁_j : u₁ j = U₁ j rowIdx := by rfl
          rw [h_u₀_j, h_u₁_j]
        rw [←h_row_eq] at h_dist_le
        exact le_trans h_dist_le hr_mem
      -- Use cardinality argument
      have h_card_line_gt_eps : R_line_set.card > ε :=
        lt_of_lt_of_le hR_star_card (Finset.card_le_card R_star_subset)
      -- Convert cardinality to probability: `Pr[P r] = card {r | P r} / card F`
      simp only [ENNReal.coe_natCast]
      rw [prob_uniform_eq_card_filter_div_card]
      simp only [ENNReal.coe_natCast]
      rw [gt_iff_lt]
      apply ENNReal.div_lt_div_right
      · simp only [ne_eq, Nat.cast_eq_zero, Fintype.card_ne_zero, not_false_eq_true]
      · exact ENNReal.natCast_ne_top (Fintype.card F)
      · exact Nat.cast_lt.mpr h_card_line_gt_eps
    -- Apply proximity gap of C to get correlated agreement at this row
    have h_corr_agree_row: Δ₀(u₀ ⋈₂ u₁, C ^⋈ (Fin 2)) ≤ e := by
      exact hC_gap (u₀) (u₁) (h_P_affineCombineRow)
    have hne : Nonempty ↑(C ^⋈ (Fin 2)) := instNonemptyInterleavedCode (κ := Fin 2) (C := C)
    let V_rowIdx := @Code.pickClosestCodeword_of_Nonempty_Code _ _ _ _ (C ^⋈ (Fin 2)) hne (u₀ ⋈₂ u₁)
    let v₀ := getRow (show (InterleavedCodeword A (Fin 2) ι C) from V_rowIdx) 0
    let v₁ := getRow (show (InterleavedCodeword A (Fin 2) ι C) from V_rowIdx) 1
    use v₀, v₁
    have h_dist_min := @Code.distFromPickClosestCodeword_of_Nonempty_Code
      _ _ _ _ (C ^⋈ (Fin 2)) hne (u₀ ⋈₂ u₁)
    rw [h_dist_min] at h_corr_agree_row
    have h_v₀_interleaved_v₁ : (V_rowIdx).val = (v₀.val ⋈₂ v₁.val) := by
      -- apply Subtype.ext;
      funext colIdx rowIdx₀₁
      by_cases h : rowIdx₀₁ = 0
      · rw [h]; rfl
      · have h' : rowIdx₀₁ = 1 := by omega
        rw [h']; rfl
    unfold pairJointProximity₂
    rw [h_v₀_interleaved_v₁] at h_corr_agree_row; exact_mod_cast h_corr_agree_row
  let V₀_wordStack : WordStack A (Fin m) ι := fun rowIdx => (V₀₁ rowIdx).1.val
  let V₁_wordStack : WordStack A (Fin m) ι := fun rowIdx => (V₀₁ rowIdx).2.1.val
  let V₀ : C ^⋈ (Fin m) := ⟨⋈| V₀_wordStack, by
    simp only [Word, interleavedCodeSet,
      interleavedCode_eq_interleavedCodeSet, WordStack, InterleavedWord,
      interleave_wordStack_eq, Set.mem_setOf_eq,
      Matrix.transpose_transpose]
    intro rowIdx; exact Subtype.coe_prop (V₀₁ rowIdx).fst
  ⟩
  let V₁ : C ^⋈ (Fin m) := ⟨⋈| V₁_wordStack, by
    simp only [Word, interleavedCodeSet,
      interleavedCode_eq_interleavedCodeSet, WordStack, InterleavedWord,
      interleave_wordStack_eq, Set.mem_setOf_eq,
      Matrix.transpose_transpose]
    intro rowIdx; exact Subtype.coe_prop (V₀₁ rowIdx).snd.fst
  ⟩
  use V₀, V₁
  intro rowIdx
  exact (V₀₁ rowIdx).2.2 -- definitional equality of V₀ V₁ according to V₀₁

open Classical in
omit [NoZeroDivisors F] [DecidableEq F] [Fintype A] [Module.Free F A] in
/-- **Lemma 3.2 (DG25): Closeness implies Closeness to Constructed Codeword**
Context:
- `C` is a linear code in `F^n` with proximity gaps for affine lines (params `e`, `ε`).
- `e` is within the unique decoding radius of `C`.
- `U₀, U₁` are ColWise-interleaved words.
- `R*` is the set of `r` in `F` such that `Uᵣ = (1-r)U₀ + rU₁` is `e`-close to `C^m`.
- `V₀, V₁` are specific codewords in `C^m` constructed row-by-row using `C`'s gap property,
  assuming `|R*| > ε`.
- `Vᵣ = (1-r)V₀ + rV₁`.
Statement: For any parameter `r` in `R*`, the matrix `Uᵣ` must be `e`-close to the codeword `Vᵣ`.
 Lemma 3.2: Given a linear code `C ⊂ F^n` with proximity gaps for affine lines
(parameters `e`, `ε`), its `m`-fold interleaving `C^m`, and two matrices
`U_0`, `U_1 ∈ F^{m × n}`, let `U_r = (1-r)U_0 + rU_1` be a point on the affine line between them,
and let `R* = { r ∈ F | d^m(U_r, C^m) ≤ e }` be the set of parameters yielding points close
to the interleaved code.
-/
lemma affineWord_close_to_affineInterleavedCodeword
    (U₀ U₁ : InterleavedWord A (Fin m) ι)
  (he : e ≤ (Code.uniqueDecodingRadius (F := A) (ι := ι) (C := MC)))
  (hC_gap : e_ε_correlatedAgreementAffineLinesNat (F := F) (C := (MC : Set (ι → A))) e ε)
  (hR_star_card : (R_star (C := (MC : Set (ι → A))) (m := m) (e := e) U₀ U₁).card > ε) :
    let ⟨V₀, V₁, _⟩ := constructInterleavedCodewordsAndRowWiseCA (F := F)
      (A := A) (ι := ι) (C := MC) (U₀ := U₀) (U₁ := U₁) (hC_gap := by exact hC_gap)
      (hR_star_card := hR_star_card)
    ∀ (r : R_star (C := MC) (m := m) (e := e) (U₀ := U₀) (U₁ := U₁)), -- Δ₀ (Uᵣ, Vᵣ) ≤ e
      Δ₀(
        affineLineEvaluation (F := F) (u₀ := U₀) (u₁ := U₁) (r := r),
        affineLineEvaluation (F := F) (u₀ := V₀.val) (u₁ := V₁.val) (r := r.val)
      ) ≤ e := by
-- 1. Setup: Define V₀, V₁, Vᵣ, r, Uᵣ
  let ⟨V₀, V₁, h_row_agreement⟩ :=
    constructInterleavedCodewordsAndRowWiseCA (F := F) (A := A) (ι := ι) (C := MC) (U₀ := U₀)
      (U₁ := U₁) (hC_gap := by exact hC_gap) (hR_star_card := hR_star_card)
  intro r_sub
  let r := r_sub.val
  set Uᵣ := affineLineEvaluation (F := F) U₀ U₁ r
  set Vᵣ := affineLineEvaluation (F := F) V₀.val V₁.val r
  -- 2. By definition of R*, there exists *some* codeword Vᵣ* close to Uᵣ
  have h_r_in_R_star := r_sub.property
  simp only [R_star, Finset.mem_filter, Finset.mem_univ, true_and] at h_r_in_R_star
  -- h_r_in_R_star is: Δ₀(Uᵣ, C ^⋈ (Fin m)) ≤ e
  -- Use `exists_closest_codeword` to get this Vᵣ*
  letI : Nonempty ↑(MC ^⋈ (Fin m)) := instNonemptyInterleavedCode A (κ := Fin m) (ι := ι) MC
  classical
  let Vᵣ_star : MC ^⋈ (Fin m) := Code.pickClosestCodeword_of_Nonempty_Code (C := MC ^⋈ (Fin m))
    (u := Uᵣ)
  have hVᵣ_star_dist : Δ₀(Uᵣ, Vᵣ_star) = Δ₀(Uᵣ, MC ^⋈ (Fin m)) := by
    dsimp only [Vᵣ_star]
    rw [Code.distFromPickClosestCodeword_of_Nonempty_Code]
  have h_dist_Uᵣ_Vᵣ_star_le_e : Δ₀(Uᵣ, Vᵣ_star) ≤ e := by
    rw [←ENat.coe_le_coe, hVᵣ_star_dist]; exact h_r_in_R_star
  -- We must show Vᵣ* = Vᵣ. We do this row-by-row.
  -- Goal is Δ₀(Uᵣ, Vᵣ) ≤ e. We will prove Vᵣ = Vᵣ_star, then rw.
  have h_Vᵣ_eq_Vᵣ_star : Vᵣ = Vᵣ_star.val := by
    change @Eq (InterleavedWord A (Fin m) ι) Vᵣ Vᵣ_star.val
    rw [eq_iff_all_rows_eq]
    intro rowIdx
    -- Get the i-th rows of Vᵣ and Vᵣ*
    set Vᵣ_i := getRow (show (InterleavedWord A (Fin m) ι) from Vᵣ) rowIdx
    set Vᵣ_star_i := getRow (show (InterleavedWord A (Fin m) ι) from Vᵣ_star.val) rowIdx
    -- ⊢ Vᵣ_i = Vᵣ_star_i
    -- 3. Show (Uᵣ)ᵢ is e-close to (Vᵣ*)ᵢ
    have h_dist_Uᵣi_Vᵣstari :
      Δ₀(getRow (show (InterleavedWord A (Fin m) ι) from Uᵣ) rowIdx, Vᵣ_star_i) ≤ e := by
      have h_Δ₀_getrow_Uᵣ_Vᵣ := dist_row_le_dist_ToInterleavedWord Uᵣ Vᵣ_star.val rowIdx
      exact le_trans h_Δ₀_getrow_Uᵣ_Vᵣ h_dist_Uᵣ_Vᵣ_star_le_e
    -- 4. Show (Uᵣ)ᵢ is e-close to (Vᵣ)ᵢ
    -- Get the row-wise agreement for row i from the constructor
    have h_agree_i := h_row_agreement rowIdx
    unfold pairJointProximity₂ at h_agree_i
    -- h_agree_i : Δ₀(getRow U₀ i ⋈₂ getRow U₁ i, getRow V₀.val i ⋈₂ getRow V₁.val i) ≤ e
    -- Show (Vᵣ)ᵢ is the affine combo of the rows of V₀, V₁
    have h_Vᵣ_i_eq_affine : Vᵣ_i =
      affineLineEvaluation (getRow V₀.val rowIdx) (getRow V₁.val rowIdx) r := by rfl
    -- Show (Uᵣ)ᵢ is the affine combo of the rows of U₀, U₁
    have h_Uᵣ_i_eq_affine : getRow (show (InterleavedWord A (Fin m) ι) from Uᵣ) rowIdx
      = affineLineEvaluation (getRow U₀ rowIdx) (getRow U₁ rowIdx) r := by rfl
    -- We need Δ₀((Uᵣ)ᵢ, (Vᵣ)ᵢ) ≤ e
    have h_dist_Uᵣi_Vᵣi :
        Δ₀(getRow (show (InterleavedWord A (Fin m) ι) from Uᵣ) rowIdx, Vᵣ_i) ≤ e := by
      -- ⊢ Δ₀(getRow (affineLineEvaluation U₀ U₁ r) rowIdx, getRow Vᵣ rowIdx) ≤ e
      have h_dist_row_le_dist_interleaved := dist_row_le_dist_ToInterleavedWord Uᵣ Vᵣ rowIdx
      -- apply le_trans h_dist_row_le_dist_interleaved
      -- ⊢ Δ₀(Uᵣ, Vᵣ) ≤ e
      -- Use the correlated agreement `h_agree_i`
      rw [h_Uᵣ_i_eq_affine, h_Vᵣ_i_eq_affine]
      apply le_trans (dist_affineCombination_le_dist_interleaved₂ _ _ _ _ _)
      -- ⊢ Δ₀(getRow U₀ rowIdx ⋈₂ getRow U₁ rowIdx, getRow (↑V₀) rowIdx ⋈₂ getRow (↑V₁) rowIdx) ≤ e
      exact h_agree_i
    -- 5. Use Unique Decoding to show (Vᵣ*)ᵢ = (Vᵣ)ᵢ
    -- We need the minimum distance d of the base code C
    let d: ℕ := ‖(MC : Set (ι → A))‖₀
    have h_d_pos : 0 < d := by
      -- Need to show d > 0. Usually codes have d ≥ 1 if not empty/trivial.
      -- Assuming d > 0 for non-trivial codes.
      rw [Code.uniqueDecodingRadius] at he
      let res :=  Code.dist_pos_of_Nontrivial (ι := ι) (F := A) (C := MC) (hC := by
        (expose_names; exact Set.nontrivial_coe_sort.mp inst_8))
      exact res
    -- We need 2e < d
    have h_2e_lt_d : 2 * e < d := by
      rw [Code.uniqueDecodingRadius] at he
      letI : NeZero ‖(MC : Set (ι → A))‖₀ := NeZero.of_pos h_d_pos
      have h_2e_lt_d := UDRClose_iff_two_mul_proximity_lt_d_UDR (C := MC) (e := e).mp (by exact he)
      exact h_2e_lt_d
    -- Apply unique decoding:
    -- Vᵣ_star_i is a codeword because it's a row of Vᵣ_star ∈ C^m
    have hVᵣ_star_i_mem : Vᵣ_star_i ∈ MC := by
      have hVᵣ_star := Vᵣ_star.property
      simp only [CodeInterleavable.interleaveCode,
        ModuleCode.moduleInterleavedCode] at hVᵣ_star
      exact hVᵣ_star rowIdx
    -- Vᵣ_i is a codeword because it's an affine combo of rows from V₀, V₁ ∈ C^m
    have hVᵣ_i_mem : Vᵣ_i ∈ MC := by
      rw [h_Vᵣ_i_eq_affine]
      apply MC.add_mem
      · apply MC.smul_mem;
        exact getRowOfInterleavedCodeword_mem_code (A := A) (κ := Fin m) (ι := ι) (C := MC)
          (u := V₀) rowIdx
      · apply MC.smul_mem;
        exact getRowOfInterleavedCodeword_mem_code (A := A) (κ := Fin m) (ι := ι) (C := MC)
          (u := V₁) rowIdx
    -- Apply the triangle inequality: d(Vᵣ_i, Vᵣ_star_i) ≤ d(Vᵣ_i, Uᵣ_i) + d(Uᵣ_i, Vᵣ_star_i)
    have h_dist_v_vstar : Δ₀(Vᵣ_i, Vᵣ_star_i) ≤
      Δ₀(Vᵣ_i, getRow (show (InterleavedWord A (Fin m) ι) from Uᵣ) rowIdx)
      + Δ₀(getRow (show (InterleavedWord A (Fin m) ι) from Uᵣ) rowIdx, Vᵣ_star_i) := by
        apply hammingDist_triangle
    -- We need to convert from ℕ∞ (Δ₀) to ℕ (hammingDist) for Code.eq_of_lt_dist
    have h_dist_v_vstar_nat : hammingDist Vᵣ_i Vᵣ_star_i < d := by
      -- Convert ℕ∞ inequalities to ℕ inequalities
      have h1_nat :
          Δ₀((getRow (show (InterleavedWord A (Fin m) ι) from Uᵣ) rowIdx), Vᵣ_i) ≤ e :=
        ENat.coe_le_coe.mp (ENat.coe_le_coe.mpr h_dist_Uᵣi_Vᵣi)
      have h2_nat :
          Δ₀((getRow (show (InterleavedWord A (Fin m) ι) from Uᵣ) rowIdx), Vᵣ_star_i) ≤ e :=
        ENat.coe_le_coe.mp (ENat.coe_le_coe.mpr h_dist_Uᵣi_Vᵣstari)
      -- Apply triangle inequality for hammingDist
      calc
        Δ₀(Vᵣ_i, Vᵣ_star_i) ≤ Δ₀(Vᵣ_i, getRow (show (InterleavedWord A (Fin m) ι) from Uᵣ) rowIdx)
          + Δ₀(getRow (show (InterleavedWord A (Fin m) ι) from Uᵣ) rowIdx, Vᵣ_star_i) :=
            hammingDist_triangle _ _ _
        _ = Δ₀(getRow (show (InterleavedWord A (Fin m) ι) from Uᵣ) rowIdx, Vᵣ_i) +
            Δ₀(getRow (show (InterleavedWord A (Fin m) ι) from Uᵣ) rowIdx, Vᵣ_star_i) := by
              rw [hammingDist_comm]
        _ ≤ e + e := Nat.add_le_add h1_nat h2_nat
        _ = 2 * e := by rw [two_mul]
        _ < d := h_2e_lt_d
    -- Now apply unique decoding
    exact Code.eq_of_lt_dist hVᵣ_i_mem hVᵣ_star_i_mem h_dist_v_vstar_nat
  -- 8. Conclude Vᵣ = Vᵣ_star and return the distance
  rw [h_Vᵣ_eq_Vᵣ_star]
  exact h_dist_Uᵣ_Vᵣ_star_le_e

open Classical in
def R_star_star_filter_columns_in_D (U₀ U₁ : InterleavedWord A (Fin m) ι)
    (V₀ V₁ : MC^⋈(Fin m)) (e : ℕ) (D : Finset ι) : Finset (F × ι) :=
  (R_star_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁ V₀.val V₁.val).filter
    (fun p => p.2 ∈ D) in
def R_star_star_filter_columns_not_in_D (U₀ U₁ : InterleavedWord A (Fin m) ι)
    (V₀ V₁ : MC ^⋈ (Fin m)) (e : ℕ) (D : Finset ι) : Finset (F × ι) :=
  (R_star_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁ V₀.val V₁.val).filter
    (fun p => p.2 ∉ D) in
omit [Nonempty ι] [NoZeroDivisors F] [Fintype A] [Module.Free F A] [Nontrivial ↥MC] in
lemma R_star_star_eq_union (U₀ U₁ : InterleavedWord A (Fin m) ι)
    (V₀ V₁ : MC ^⋈ (Fin m)) (e : ℕ) (D : Finset ι):
  (R_star_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁ V₀.val V₁.val) =
    (R_star_star_filter_columns_not_in_D MC U₀ U₁ V₀ V₁ (e := e) D)
    ∪ (R_star_star_filter_columns_in_D MC U₀ U₁ V₀ V₁ (e := e) D) := by
  dsimp only [R_star_star, Lean.Elab.WF.paramLet, R_star_star_filter_columns_not_in_D,
    R_star_star_filter_columns_in_D]
  rw [Finset.union_comm]
  rw [Finset.filter_union_filter_not_eq]

omit [Nonempty ι] [NoZeroDivisors F] [DecidableEq F] [Fintype A]
  [Module.Free F A] [Nontrivial ↥MC] in
open Classical in
lemma disjoint_R_star_star_filter_columns_in_D_not_in_D (U₀ U₁ : InterleavedWord A (Fin m) ι)
    (V₀ V₁ : MC^⋈(Fin m)) (e : ℕ) (D : Finset ι) :
  Disjoint (R_star_star_filter_columns_in_D MC U₀ U₁ V₀ V₁ (e := e) D)
    (R_star_star_filter_columns_not_in_D MC U₀ U₁ V₀ V₁ (e := e) D) := by
-- 1. Unfold the definitions to reveal the underlying `filter` structure
  unfold R_star_star_filter_columns_in_D R_star_star_filter_columns_not_in_D
  -- The goal is now `Disjoint (R_ss.filter P) (R_ss.filter (¬P))`
  apply disjoint_filter_filter_not

set_option maxHeartbeats 400000 in
-- Destructured `let` avoids repeated elaboration of
-- `constructInterleavedCodewordsAndRowWiseCA`
omit [NoZeroDivisors F] [DecidableEq F] [Fintype A] [Module.Free F A] in
lemma D_card_le_e_implies_interleaved_correlatedAgreement₂
    (U₀ U₁ : InterleavedWord A (Fin m) ι)
  (hC_gap : e_ε_correlatedAgreementAffineLinesNat (F := F) (C := MC) e ε)
  (hR_star_card : (R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁).card > ε) :
    let ⟨V₀, V₁, _⟩ := constructInterleavedCodewordsAndRowWiseCA (F := F)
      (A := A) (ι := ι) (C := MC) (U₀ := U₀) (U₁ := U₁) (hC_gap := by exact hC_gap)
      (hR_star_card := hR_star_card)
    (disagreementSet U₀ U₁ V₀ V₁).card ≤ e
    → jointProximityNat₂ (C := MC ^⋈ (Fin m)) U₀ U₁ e := by
  -- 1. Unfold definitions and simplify
  set C_m := MC ^⋈ (Fin m)
  set U_rowwise := finMapTwoWords U₀ U₁
  set U_colwise := ⋈| U_rowwise
  set C_m_2 := C_m ^⋈ (Fin 2)
  -- Unfold the goal
  unfold jointProximityNat₂
  -- Goal: (let ⟨V₀, V₁, _⟩ := ... in (disagreementSet ...).card ≤ e) → (Δ₀(U_comb, C_m_2) ≤ e)
  simp only
  -- 2. Introduce the bindings and the hypothesis
  intro hDisagreeementCard_Le_e -- The assumption: (disagreementSet U₀ U₁ V₀ V₁).card ≤ e
  set V₀ := (constructInterleavedCodewordsAndRowWiseCA (F := F)
    (A := A) (ι := ι) (C := MC) (U₀ := U₀) (U₁ := U₁) (hC_gap := by exact hC_gap)
    (hR_star_card := hR_star_card)).1
  set V₁ := (constructInterleavedCodewordsAndRowWiseCA (F := F)
    (A := A) (ι := ι) (C := MC) (U₀ := U₀) (U₁ := U₁) (hC_gap := by exact hC_gap)
    (hR_star_card := hR_star_card)).2.1
  set hRowPairCA_U_V := (constructInterleavedCodewordsAndRowWiseCA
    (F := F) (A := A) (ι := ι) (C := MC) (U₀ := U₀) (U₁ := U₁) (hC_gap := by exact hC_gap)
    (hR_star_card := hR_star_card)).2.2
  have hD_card_le_e : #(disagreementSet U₀ U₁ V₀ V₁) ≤ e :=
    hDisagreeementCard_Le_e
  -- 3. Show LHS assumption is equal to Δ₀(U_comb, V_constructed) ≤ e
  set V_rowwise := finMapTwoWords V₀.val V₁.val
  set V_colwise := ⋈| V_rowwise
  have h_LHS_eq_dist : (disagreementSet U₀ U₁ V₀ V₁).card = Δ₀(U_colwise, V_colwise) := by
    unfold disagreementSet U_colwise V_colwise
    unfold Interleavable.interleave U_rowwise V_rowwise hammingDist Finset.filter
    congr 1
    simp only [ne_eq]
    congr 1
    congr 1
    funext colIdx
    simp only [eq_iff_iff]
    constructor
    · intro hleft
      by_contra h_fun_eq
      rw [funext_iff] at h_fun_eq
      by_cases h_left_1: ¬U₀ colIdx = V₀.val colIdx
      · simp only [h_left_1, not_false_eq_true, true_or] at hleft
        have h_U₀_eq_V₀ := h_fun_eq 0
        exact h_left_1 h_U₀_eq_V₀
      · simp only [h_left_1, false_or] at hleft
        have h_U₁_eq_V₁ := h_fun_eq 1
        exact h_left_1 fun a ↦ hleft h_U₁_eq_V₁
    · intro h_fun_ne
      rw [funext_iff] at h_fun_ne
      rw [not_forall] at h_fun_ne
      rcases h_fun_ne with ⟨i_fin2, h_fun_ne_i⟩
      fin_cases i_fin2
      · simp only at h_fun_ne_i
        left
        exact h_fun_ne_i
      · simp only at h_fun_ne_i
        right
        exact h_fun_ne_i
  -- Our assumption `h_LHS` is now: Δ₀(U_comb, V_constructed) ≤ e
  simp_rw [h_LHS_eq_dist] at hD_card_le_e
  -- 4. Prove the RHS: Δ₀(U_comb, C_m_2) ≤ e
  rw [jointProximityNat]
  rw [Code.closeToCode_iff_closeToCodeword_of_minDist]
  -- ⊢ ∃ v ∈ ↑(C ^⋈ (Fin 2) ^⋈ (Fin m)),
  -- Δ₀(⋈|finMapTwoWords U₀ U₁, v) ≤ e
  use V_colwise
  constructor
  · intro k
    match k with
    | ⟨0, _⟩ => exact V₀.property
    | ⟨1, _⟩ => exact V₁.property
  · exact hD_card_le_e

omit [Nonempty ι] [NoZeroDivisors F] [DecidableEq F] [Fintype A] [Module.Free F A]
  [Nontrivial ↥MC] in
/-- **Lemma 3.3 (Part 1): Bound on agreeing cells outside D**
    The set of agreeing cells `(r, j)` where `j ∉ D` is exactly the
    Cartesian product of `R*` and `Dᶜ` (the columns not in D).
-/
lemma card_agreeing_cells_notin_D {U₀ U₁ : InterleavedWord A (Fin m) ι} {V₀ V₁ : MC^⋈(Fin m)}
    {e : ℕ} (D : Finset ι)
    (h_D_def : D = disagreementSet U₀ U₁ V₀.val V₁.val) :
    (R_star_star_filter_columns_not_in_D MC U₀ U₁ V₀ V₁ e D).card
    = (R_star (A := A) (F := F) (ι := ι) (C := MC) (e := e) U₀ U₁).card
      * (Fintype.card ι - D.card) := by
  -- sorry
  classical
  let n := Fintype.card ι
  let D_compl := Finset.univ \ D
-- Define local abbreviations
  let n := Fintype.card ι
  let D_compl := Finset.univ \ D
  let R_s := R_star (F := F) (A := A) (ι := ι) (C := MC) (e := e) U₀ U₁
  let R_ss_not_D := R_star_star_filter_columns_not_in_D MC U₀ U₁ V₀ V₁ e D
  -- 1. Prove that R_ss_not_D is equal to the product R_s ×ˢ D_compl
  have h_set_eq : R_ss_not_D = R_s ×ˢ D_compl := by
    -- We prove equality by showing element-wise equivalence
    ext p
    rcases p with ⟨r, j⟩
    -- Unfold all definitions
    simp only [R_star_star_filter_columns_not_in_D, R_star_star, mem_filter, mem_product, mem_univ,
      and_true, R_ss_not_D, R_s, D_compl]
    constructor
    · rintro ⟨⟨hr, _⟩, hj⟩
      exact ⟨hr, mem_sdiff.mpr ⟨mem_univ _, hj⟩⟩
    · rintro ⟨hr, hj⟩
      have hj' := (mem_sdiff.mp hj).2
      refine ⟨⟨hr, ?_⟩, hj'⟩
      have h_agree : U₀ j = V₀.val j ∧ U₁ j = V₁.val j := by
        simp only [h_D_def, disagreementSet, mem_filter, mem_univ, true_and,
          not_or, not_not] at hj'
        exact hj'
      unfold affineLineEvaluation
      simp only [Pi.add_apply, Pi.smul_apply, h_agree.1, h_agree.2]
  have h_set_card_eq : R_ss_not_D.card = R_s.card * D_compl.card := by
    rw [h_set_eq]
    simp only [card_product]
  -- 2. Now calculate the cardinality using the set equality
  grind only [usr le_card_sdiff, = card_sdiff_of_subset, = card_univ, = subset_iff, ← mem_univ]



omit [Nonempty ι] [DecidableEq F] [Fintype A] [Nontrivial ↥MC] in
/-- **Lemma 3.3 (Part 2): Bound on agreeing cells inside D**
For any column `j` that *is* in the disagreement set `D`, there is at most one
parameter `r` in `R*` such that the columns `Uᵣ j` and `Vᵣ j` agree.
Therefore, the total number of agreeing cells `(r, j)` with `j ∈ D` is at most `|D|`.
-/
lemma card_agreeing_cells_in_D_le
    {U₀ U₁ : InterleavedWord A (Fin m) ι}
    {V₀ V₁ : MC^⋈(Fin m)}
    {e : ℕ} (D : Finset ι)
    (h_D_def : D = disagreementSet U₀ U₁ V₀.val V₁.val) :
    (R_star_star_filter_columns_in_D MC U₀ U₁ V₀ V₁ e D).card ≤ D.card := by
  classical
  -- Let R_ss_in_D be the set of agreeing cells (r, j) with j ∈ D
  let R_ss_in_D := R_star_star_filter_columns_in_D MC U₀ U₁ V₀ V₁ e D
  -- 1. The card of a set is bounded by the sum of the cardinalities of its fibers
  --    (We are "slicing" the set by its second component, the column index j)
  have h_card_eq_sum_fibers : R_ss_in_D.card
    = ∑ j ∈ D, ((R_ss_in_D.filter (fun p => p.2 = j)).card) := by
      apply Finset.card_eq_sum_card_fiberwise (f := Prod.snd) (t := D)
      -- We must show that every element in R_ss_in_D maps to an element in D
      -- Goal: `Set.MapsTo (Prod.snd) R_ss_in_D D`, this means: `∀ p ∈ R_ss_in_D, p.2 ∈ D`
      intro p hp_in_Rss
      -- This is true by the very definition of R_ss_in_D!
      unfold R_ss_in_D R_star_star_filter_columns_in_D at hp_in_Rss
      simp only [coe_filter, Set.mem_setOf_eq] at hp_in_Rss
      -- hp_in_Rss is `p ∈ R_star_star ∧ p.2 ∈ D`
      exact hp_in_Rss.2
  -- 2. We prove that each fiber (for a fixed j) has cardinality at most 1
  have h_fibers_le_one_sum :
    ∑ j ∈ D, ((R_ss_in_D.filter (fun p => p.2 = j)).card) ≤ ∑ j ∈ D, 1 := by
    apply Finset.sum_le_sum
    intro j hj_in_D -- For any column j that is in the disagreement set D
    -- Goal for this term: (R_ss_in_D.filter (fun p => p.2 = j)).card ≤ 1
    apply Finset.card_le_one_iff.mpr
    -- Goal: ∀ p1 p2, p1 ∈ ... → p2 ∈ ... → p1 = p2
    -- We MUST introduce two elements (p1, p2) and their two proofs (hp1, hp2)
    intro p1 p2 hp1 hp2
    rcases p1 with ⟨r₁, j₁⟩
    rcases p2 with ⟨r₂, j₂⟩
    -- ⊢ (r₁, j₁) = (r₂, j₂)
    apply Prod.ext
    · -- Goal 1: Prove r₁ = r₂: We need to extract the agreement properties from the hypotheses
      have h1_in_Rss : (r₁, j₁) ∈ R_ss_in_D := (Finset.mem_filter.mp hp1).1
      have h1_j_eq : j₁ = j := (Finset.mem_filter.mp hp1).2
      have h2_in_Rss : (r₂, j₂) ∈ R_ss_in_D := (Finset.mem_filter.mp hp2).1
      have h2_j_eq : j₂ = j := (Finset.mem_filter.mp hp2).2
      -- Get the agreement properties from R_ss_in_D
      have h1_agree : affineLineEvaluation U₀ U₁ r₁ j = affineLineEvaluation (↑V₀) (↑V₁) r₁ j := by
        -- Unfold R_ss_in_D and R_star_star to find the agreement
        unfold R_ss_in_D R_star_star_filter_columns_in_D at h1_in_Rss
        simp only [R_star_star, mem_filter, mem_product, mem_univ, and_true] at h1_in_Rss
        rw [← h1_j_eq] -- Use j₁ = j
        exact h1_in_Rss.1.2
      have h2_agree : affineLineEvaluation U₀ U₁ r₂ j = affineLineEvaluation (↑V₀) (↑V₁) r₂ j := by
        unfold R_ss_in_D R_star_star_filter_columns_in_D at h2_in_Rss
        simp only [R_star_star, mem_filter, mem_product, mem_univ, and_true] at h2_in_Rss
        rw [← h2_j_eq] -- Use j₂ = j
        exact h2_in_Rss.1.2 -- This is the `Uᵣ j = Vᵣ j` part
      -- linear algebra argument
      let W₀ := U₀ j - V₀.val j
      let W₁ := U₁ j - V₁.val j
      have h_eq_r1 : W₀ + r₁ • (W₁ - W₀) = 0 := by
        unfold affineLineEvaluation at h1_agree
        rw [← sub_eq_zero] at h1_agree
        rw [← h1_agree]
        unfold W₀ W₁
        -- ⊢ U₀ j - ↑V₀ j + r₁ • (U₁ j - ↑V₁ j - (U₀ j - ↑V₀ j)) = ((1 - r₁) • U₀ + r₁ • U₁) j
          -- - ((1 - r₁) • ↑V₀ + r₁ • ↑V₁) j
        simp only [Pi.add_apply, Pi.smul_apply]
        rw [sub_smul, sub_smul]; rw [smul_sub, smul_sub, smul_sub]
        simp only [one_smul]
        abel_nf
      have h_eq_r2 : W₀ + r₂ • (W₁ - W₀) = 0 := by
        unfold affineLineEvaluation at h2_agree
        rw [← sub_eq_zero] at h2_agree
        rw [← h2_agree]
        unfold W₀ W₁
        simp only [Pi.add_apply, Pi.smul_apply]
        rw [sub_smul, sub_smul]; rw [smul_sub, smul_sub, smul_sub]
        simp only [one_smul]
        abel_nf
      have h_j_in_D : W₀ ≠ 0 ∨ W₁ ≠ 0 := by
        simp only [h_D_def, disagreementSet, ne_eq, mem_filter, mem_univ, true_and] at hj_in_D
        by_cases h₀_ne: ¬U₀ j = V₀.val j
        · left
          dsimp only [W₀]
          exact sub_ne_zero_of_ne h₀_ne
        · simp only [h₀_ne, false_or] at hj_in_D
          right
          dsimp only [W₁]
          exact sub_ne_zero_of_ne hj_in_D
      by_cases h_diff_eq_zero : W₁ - W₀ = 0
      · -- Case 1: W₁ - W₀ = 0
        have h_W₀_zero : W₀ = 0 := by rwa [h_diff_eq_zero, smul_zero, add_zero] at h_eq_r1
        have h_W₁_zero : W₁ = 0 := by
          rw [←h_diff_eq_zero, h_W₀_zero];
          exact Eq.symm (sub_zero W₁)
        by_cases h_W₀_ne_zero : W₀ ≠ 0
        · exact False.elim (h_W₀_ne_zero h_W₀_zero)
        · have h_W₁_ne_0 : W₁ ≠ 0 := by
            exact h_j_in_D.resolve_left h_W₀_ne_zero
          exact False.elim (h_W₀_ne_zero fun a ↦ h_W₁_ne_0 h_W₁_zero)
      · -- Case 2: W₁ - W₀ ≠ 0 (this is `h_diff_eq_zero : ¬W₁ - W₀ = 0`)
        -- 2 hypotheses: h_eq_r1 : W₀ + r₁ • (W₁ - W₀) = 0, h_eq_r2 : W₀ + r₂ • (W₁ - W₀) = 0
        have h_eq_both : W₀ + r₁ • (W₁ - W₀) = W₀ + r₂ • (W₁ - W₀) := by
          rw [h_eq_r1, h_eq_r2]
        have h_smul_eq : r₁ • (W₁ - W₀) = r₂ • (W₁ - W₀) :=
          (add_right_inj W₀).mp h_eq_both
        have h_sub_smul_eq_zero : (r₁ - r₂) • (W₁ - W₀) = 0 := by
          rw [sub_smul, sub_eq_zero]
          exact h_smul_eq
        rw [smul_eq_zero] at h_sub_smul_eq_zero
        have h_r_sub_eq_zero : r₁ - r₂ = 0 := by
          exact h_sub_smul_eq_zero.resolve_right h_diff_eq_zero
        exact sub_eq_zero.mp h_r_sub_eq_zero
    · -- Goal 2: Prove j₁ = j₂: This follows directly from the fiber proofs
      have h1_j_eq : j₁ = j := (Finset.mem_filter.mp hp1).2
      have h2_j_eq : j₂ = j := (Finset.mem_filter.mp hp2).2
      rw [h1_j_eq, h2_j_eq]
  -- 3. Chain the inequalities: R_ss_in_D.card ≤ (∑ j in D, 1) ≤ D.card
  simp only [sum_const, smul_eq_mul, mul_one] at h_fibers_le_one_sum
  exact le_trans (Nat.le_of_eq h_card_eq_sum_fibers) h_fibers_le_one_sum

omit [Fintype A] [DecidableEq F] in
/-- **Lemma 3.3 (DG25): Upper Bound on R** Cardinality**
Context:
- `U₀, U₁` are columnWise words; `V₀, V₁` are columnWise codewords
- `R_star` is the set where affine combinations `Uᵣ` are close to `C^m`.
- `D` is the set of columns where `U₀` differs from `V₀` OR `U₁` differs from `V₁`.
- `R_star_star` is the set of pairs `(r, j)` where `r ∈ R_star` and column `j` of `Uᵣ`
equals column `j` of `Vᵣ` (set of `agreeing linearComb columns`)
Statement: The number of agreeing column pairs `(r, j)` is bounded by the number
of parameters in `R_star` times the number of columns *outside* `D`, plus the
number of columns *inside* `D`.
`|R**| ≤ |R*| * (n - |D|) + |D|`
-/
lemma R_star_star_upper_bound
    (U₀ U₁ : InterleavedWord A (Fin m) ι)
    (hC_gap : e_ε_correlatedAgreementAffineLinesNat (A := A) (ι := ι) (C := MC) e ε)
    (hR_star_card : (R_star (A := A) (F := F) (ι := ι) (C := MC)
      (m := m) (e := e) U₀ U₁).card > ε) :
      let ⟨V₀, V₁, _⟩ := constructInterleavedCodewordsAndRowWiseCA (F := F)
        (A := A) (ι := ι) (C := MC) (U₀ := U₀) (U₁ := U₁) (hC_gap := by exact hC_gap)
        (hR_star_card := hR_star_card)
      let D : Finset ι := disagreementSet U₀ U₁ V₀ V₁
      (R_star_star (A := A) (ι := ι) (F := F) (C := MC) (m := m) (e := e) U₀ U₁ V₀ V₁).card
        ≤ (R_star (A := A) (ι := ι) (F := F) (C := MC) (m := m) (e := e) U₀ U₁).card *
          (Fintype.card ι - D.card) + D.card := by
  classical -- Use classical logic for decidable predicates on filters
  -- 1. Define local variables
  let ⟨V₀, V₁, _⟩ := constructInterleavedCodewordsAndRowWiseCA (F := F)
        (A := A) (ι := ι) (C := MC) (U₀ := U₀) (U₁ := U₁) (hC_gap := by exact hC_gap)
        (hR_star_card := hR_star_card)
  let n := Fintype.card ι
  let R_s := R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁
  let D := disagreementSet U₀ U₁ V₀.val V₁.val
  set R_ss := R_star_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁ V₀.val V₁.val
  set R_ss_in_D    := (R_star_star_filter_columns_in_D MC U₀ U₁ V₀ V₁ e D)
  set R_ss_notin_D := (R_star_star_filter_columns_not_in_D MC U₀ U₁ V₀ V₁ e D)
  -- 3. The card of R_ss is the sum of the cards of the disjoint partition.
  have h_card_split : R_ss.card = R_ss_notin_D.card + R_ss_in_D.card := by
    rw [← Finset.card_union_of_disjoint]
    · congr
      exact R_star_star_eq_union MC U₀ U₁ V₀ V₁ e D
    · exact Disjoint.symm (disjoint_R_star_star_filter_columns_in_D_not_in_D MC U₀ U₁ V₀ V₁ e D)
  -- 4. Apply the split
  simp only
  rw [h_card_split]
  -- Goal: R_ss_notin_D.card + R_ss_in_D.card ≤ R_s.card * (n - D.card) + D.card

  -- 5. Apply the two new lemmas
  apply add_le_add
  · -- Prove R_ss_notin_D.card ≤ R_s.card * (n - D.card)
    have h_notin_D := card_agreeing_cells_notin_D MC (m := m) (e := e) (U₀ := U₀) (U₁ := U₁)
      (V₀ := V₀) (V₁ := V₁) D (by rfl)
    exact Nat.le_of_eq h_notin_D
  · -- Prove R_ss_in_D.card ≤ D.card
    have h_in_D := card_agreeing_cells_in_D_le MC (m := m) (e := e) (U₀ := U₀) (U₁ := U₁)
      (V₀ := V₀) (V₁ := V₁) D (by rfl)
    exact h_in_D

omit [NoZeroDivisors F] [DecidableEq F] [Fintype A] [Module.Free F A] in
/-- **Lemma 3.4 (DG25): Lower Bound on R** Cardinality**
Context:
- Same as Lemma 3.2, including hypotheses on `C`, `e`, `V₀`, `V₁`, `R_star`.
- `R_star_star` is the set of pairs `(r, j)` where `r ∈ R_star` and column `j` of `Uᵣ`
equals column `j` of `Vᵣ`.
Statement: The number of agreeing column pairs `(r, j)` is at least the number
of parameters in `R_star` times the number of columns guaranteed to agree (`n - e`)
for each `r` (using Lemma 3.2), i.e. `|R**| ≥ (n - e) * |R*|`
-/
lemma R_star_star_lower_bound
    (U₀ U₁ : InterleavedWord A (Fin m) ι)
    (he : e ≤ (Code.uniqueDecodingRadius (F := A) (ι := ι) (C := MC)))
    (hC_gap : e_ε_correlatedAgreementAffineLinesNat (A := A) (ι := ι) (C := MC) e ε)
    (hR_star_card : (R_star (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁).card > ε) :
      let ⟨V₀, V₁, _⟩ := constructInterleavedCodewordsAndRowWiseCA (F := F)
        (A := A) (ι := ι) (C := MC) (U₀ := U₀) (U₁ := U₁) (hC_gap := by exact hC_gap)
        (hR_star_card := hR_star_card)
      (R_star_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁ V₀ V₁).card
        >= (Fintype.card ι - e) *
          (R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁).card := by
  classical
  /- DG25 Proof Sketch:
     Sum over r ∈ R*. For each such r:
     Apply Lemma 3.2 (using h_agree, he_udr, hR_star): Δ^m(Uᵣ, Vᵣ) ≤ e.
     By definition of Δ^m, this means Uᵣ and Vᵣ agree on ≥ n - e columns j.
     So, row r contributes ≥ n - e to |R**|.
     Summing gives |R**| ≥ |R*| * (n - e).
  -/
  -- 1. Define local variables
  let V₀ := (constructInterleavedCodewordsAndRowWiseCA (F := F)
        (A := A) (ι := ι) (C := MC) (U₀ := U₀) (U₁ := U₁) (hC_gap := by exact hC_gap)
        (hR_star_card := hR_star_card)).1
  let V₁ := (constructInterleavedCodewordsAndRowWiseCA (F := F)
        (A := A) (ι := ι) (C := MC) (U₀ := U₀) (U₁ := U₁) (hC_gap := by exact hC_gap)
        (hR_star_card := hR_star_card)).2.1
  let n := Fintype.card ι
  let R_s := R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁
  let R_ss := R_star_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁ V₀.val V₁.val
  simp only [ge_iff_le]
  simp only [R_star_star]
  rw [Finset.card_filter]
  rw [Finset.sum_product]
  have h_card_ge_per_r: ∀ r : R_star (A := A) (F := F) (ι := ι) (C := MC)
    (e := e) U₀ U₁, (Fintype.card ι - e) ≤ (∑ j, if
      affineLineEvaluation (F := F) U₀ U₁ (r, j).1 (r, j).2
      = affineLineEvaluation (F := F) V₀.val V₁.val (r, j).1 (r, j).2 then 1 else 0) := by
    intro r
      -- Let Uᵣ and Vᵣ be the affine points for this r
    let Uᵣ := affineLineEvaluation (F := F) U₀ U₁ r
    let Vᵣ := affineLineEvaluation (F := F) V₀.val V₁.val r
    -- The sum is the number of agreeing columns, which is `n - hammingDist(Uᵣ, Vᵣ)`
    have h_sum_eq_agreeing_cols :
        (∑ j, if Uᵣ j = Vᵣ j then 1 else 0) = n - Δ₀(Uᵣ, Vᵣ) := by
      -- 1. `∑ j, if P j then 1 else 0` is the definition of `(Finset.filter P Finset.univ).card`
      rw [Finset.sum_boole]
      -- 2. Unfold the notation
      -- `n` is `(Finset.univ : Finset ι).card`
      dsimp only [Nat.cast_id, n]
      rw [←Finset.card_univ]
      -- `Δ₀(Uᵣ, Vᵣ)` is `hammingDist Uᵣ Vᵣ`
      unfold hammingDist
      apply Nat.eq_sub_of_add_eq
      rw [Finset.card_filter, Finset.card_filter]
      rw [← Finset.sum_add_distrib]
      simp_rw [ne_eq]
      -- simp will solve the `ite` logic and apply `sum_const_one`
      simp only [ite_not, card_univ]
      have h_inner :
          ∀ x, ((if Uᵣ x = Vᵣ x then 1 else 0) + if Uᵣ x = Vᵣ x then 0 else 1) = 1 := fun x => by
        by_cases h : Uᵣ x = Vᵣ x
        · simp only [h, if_true]
        · simp only [h, if_false]
      simp_rw [h_inner]
      simp only [sum_const, card_univ, smul_eq_mul, mul_one]
    rw [h_sum_eq_agreeing_cols]
    -- Goal: n - e ≤ n - hammingDist Uᵣ Vᵣ
    -- This is equivalent to `hammingDist Uᵣ Vᵣ ≤ e`
    -- We use `Nat.sub_le_sub_left_iff` which requires `hammingDist Uᵣ Vᵣ ≤ n`
    have h_dist_le_n : hammingDist Uᵣ Vᵣ ≤ e := by
    -- This is exactly the conclusion of Lemma 3.2 (affineWord_close_to_affineInterleavedCodeword)
      let res := affineWord_close_to_affineInterleavedCodeword (U₀ := U₀) (U₁ := U₁)
        (he := he) (hC_gap := by exact hC_gap) (hR_star_card := hR_star_card) (r := r)
      simp only [Fin.isValue, eq_mpr_eq_cast, cast_eq, ENNReal.coe_natCast,
        Lean.Elab.WF.paramLet] at res
      exact res
    exact Nat.sub_le_sub_left h_dist_le_n (Fintype.card ι)
  have h_left : (Fintype.card ι - e) * #(R_star (A := A) (F := F) (ι := ι) (C := MC) (e := e) U₀ U₁)
    = ∑ r ∈ R_star (A := A) (F := F) (ι := ι) (C := MC) (e := e) U₀ U₁, (Fintype.card ι - e) := by
    rw [Finset.sum_const]
    simp only [smul_eq_mul]
    exact Nat.mul_comm (Fintype.card ι - e) #(R_star (A := A) (F := F) (ι := ι) (C := MC) U₀ U₁)
  rw [h_left]
  apply Finset.sum_le_sum
  intro r hr_mem
  exact h_card_ge_per_r (Subtype.mk r hr_mem)

omit [NoZeroDivisors F] [Module.Free F A] [Nonempty ι] [Fintype A] [DecidableEq F]
  [DecidableEq ι] [Nontrivial ↥MC] in
lemma probShadedAffineCombInterleavedCodeword_gt_threshold_iff
    (U₀ U₁ : InterleavedWord A (Fin m) ι) :
  Pr_{ let r ←$ᵖ F }[
    Δ₀(affineLineEvaluation (F := F) U₀ U₁ r,
      MC ^⋈ (Fin m)) ≤ e ] > ((ε: ℝ≥0) / (Fintype.card F : ℝ≥0))
  ↔ (R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁).card > ε := by
  conv_lhs =>
    rw [prob_uniform_eq_card_filter_div_card]
    rw [gt_iff_lt]
    simp only [ENNReal.coe_natCast]
    simp only [ne_eq, Nat.cast_eq_zero, Fintype.card_ne_zero, not_false_eq_true,
      ENNReal.natCast_ne_top, ENNReal.div_lt_div_iff_left (c := ((Fintype.card F) : ENNReal)),
      Nat.cast_lt]
    rw [←gt_iff_lt]
  rfl

/--
This lemma proves the final algebraic step in the DG25 Theorem 3.1 proof.
It shows that if `R > e + 1`, then `e * (R / (R - 1)) < e + 1`.

The intuition is that the fraction `R / (R - 1)` is always greater than 1,
but as `R` gets larger, it gets closer to 1. The hypothesis `R > e + 1`
provides a strong enough bound to ensure the product `e * (fraction)`
doesn't "overshoot" `e + 1`.
-/
lemma e_mul_R_div_R_sub_1_lt_e_add_1_real {e R : ℕ} (hR_gt_e_add_1 : e + 1 < R) :
    ((e : ℝ) * (R : ℝ)) / ((R : ℝ) - 1) < (e : ℝ) + 1 := by
  have hR_gt_one : R > 1 := by omega
  have hR_Real_gt_one : (R : ℝ) > 1 := by exact Nat.cast_gt_Real_one R hR_gt_one
  have h_R_gt_e_add_1_real : ((e + 1) : ℝ) < (R : ℝ) := by
    rw [←Nat.cast_add_one (n := e)]
    apply Nat.cast_lt (α := ℝ) (m := e + 1) (n := R).mpr hR_gt_e_add_1
  have h_denom_pos : (R : ℝ) - 1 > 0 := by
    -- `linarith` solves this from the hypothesis
    linarith [hR_Real_gt_one]
  -- 3. Use `div_lt_iff` to multiply the denominator across
  -- This is the `ℝ` lemma for `a / b < c ↔ a < c * b` (since `b > 0`)
  rw [div_lt_iff₀ (hc := h_denom_pos)]
  -- Goal: ⊢ ↑e * ↑R < (↑e + 1) * (↑R - 1)
  -- 4. THIS IS THE KEY STEP
  -- Don't use `rw`. `linarith` will:
  --   a) Expand the RHS to: `e*R - e + R - 1`
  --   b) See the goal: `e*R < e*R - e + R - 1`
  --   c) Cancel `e*R` from both sides: `0 < R - e - 1`
  --   d) Rearrange: `e + 1 < R`
  --   e) See this is exactly your hypothesis `h_R_gt_e_add_1_real`
  linarith [h_R_gt_e_add_1_real]

open Classical in
omit [Fintype A] [DecidableEq F] in
/- **Theorem 3.1**. If `C` features proximity gaps for affine lines with respect to the
proximity parameter `e ∈ {0, ..., ⌊(d-1)/2⌋}` and the false witness bound
`ε ≥ e+1`, then, for each `m > 1`, `C`'s interleaving `C^m` also does.
-/
theorem affine_gaps_lifted_to_interleaved_codes {m : ℕ} {ε : ℕ}
    {e : ℕ} (he : e ≤ (Code.uniqueDecodingRadius (F := A) (ι := ι) (C := MC))) (hε : ε ≥ e + 1)
    (hProximityGapAffineLines :
      e_ε_correlatedAgreementAffineLinesNat (F := F) (C := (MC : Set (ι → A))) (e := e) (ε := ε)) :
    e_ε_correlatedAgreementAffineLinesNat (ι := ι) (F := F) (A := InterleavedSymbol A (Fin m))
      (C := ((MC^⋈(Fin m)) : Set (ι → (InterleavedSymbol A (Fin m))))) (e := e) (ε := ε) := by
  -- 1. Unfold the definition of e_ε_correlatedAgreementAffineLinesNat for the interleaved code C^m.
  -- We must show that for any two words U₀, U₁, if the set of "close" affine
  -- combinations (R*) is large, then U₀ and U₁ have correlated agreement with C^m.
  intro U₀ U₁ hR_prob_shaded_affine_comb_gt_threshold
  -- `⊢ ModuleCode.correlatedAgreement₂ U₀ U₁ ↑e, i.e. |D| ≤ e`

  -- 2. Assume the hypothesis: |R*| > ε
  let hR_star_card_gt_ε := probShadedAffineCombInterleavedCodeword_gt_threshold_iff
    (F := F) (A := A) (ι := ι) (MC := MC) (m := m)
    (U₀ := U₀) (U₁ := U₁) (ε := ε) (e := e).mp hR_prob_shaded_affine_comb_gt_threshold
  have hR_star_card_gt1 : (R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m)
    (e := e) U₀ U₁).card > 1 := by omega  -- |R*| > ε ≥ e + 1 ≥ 1
  have hR_star_card_gt1_Real : ((R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m)
    (e := e) U₀ U₁).card : ℝ) > 1 := by
    exact Nat.cast_gt_Real_one (R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m)
      (e := e) U₀ U₁).card hR_star_card_gt1
  -- 3. Use the hypothesis on the base code C (hProximityGapAffineLines)
  -- and the fact that |R*| > ε to construct the candidate
  -- interleaved codewords V₀ and V₁ in C^m.
  set V := constructInterleavedCodewordsAndRowWiseCA (F := F) (A := A) (ι := ι) (C := MC) (m := m)
    (U₀ := U₀) (U₁ := U₁)
    hProximityGapAffineLines (hR_star_card_gt_ε)
  let V₀ := V.1; let V₁ := V.2.1; let h_row_agreement := V.2.2
  set D := disagreementSet U₀ U₁ V₀ V₁
  have h_D_card_le_n : D.card ≤ Fintype.card ι := by
    dsimp only [disagreementSet, ne_eq, D]
    let res := Finset.card_filter_le (s := Finset.univ (α := ι))
      (p := fun colIdx => ¬U₀ colIdx = V₀.val colIdx ∨ ¬U₁ colIdx = V₁.val colIdx)
    rw [Finset.card_univ] at res
    convert res
  have h_D_le_D_mul_R_star_card: D.card ≤ D.card * (R_star (A := A) (F := F) (ι := ι)
    (C := MC) (m := m) (e := e) U₀ U₁).card := by
    conv_lhs => rw [←Nat.mul_one D.card]
    apply Nat.mul_le_mul_left; exact Nat.one_le_of_lt hR_star_card_gt_ε
  -- `e · |R*| ≥ |D| · (|R*| - 1)
  have h_e_mul_Rstar_card_ge:
    e * (R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁).card
      ≥ D.card * (R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁).card
        - D.card := by
    -- This comes from lemma 3.3: |R**| ≤ |R*|(n - |D|) + |D|
    -- and lemma 3.4: |R**| ≥ (n - e)|R*|
    have h_lemma_3_3 := R_star_star_upper_bound (MC := MC) (ε := ε) (m := m) (e := e)
      U₀ U₁ hProximityGapAffineLines hR_star_card_gt_ε
    have h_lemma_3_4 := R_star_star_lower_bound (MC := MC) (ε := ε) (m := m) (e := e)
      (U₀ := U₀) (U₁ := U₁) (he := he) hProximityGapAffineLines hR_star_card_gt_ε
    simp only [ge_iff_le] at h_lemma_3_3 h_lemma_3_4
    set n := Fintype.card ι
    -- So (n - e)|R*| ≤ |R**| ≤ |R*|(n - |D|) + |D|
    have h_le_trans := le_trans h_lemma_3_4 h_lemma_3_3
    -- ↔ n * |R*| - e * |R*| ≤ n * |R*| - |D| * |R*| + |D|
    rw [Nat.sub_mul (n := n) (m := e), Nat.mul_sub (n := (R_star (A := A) (F := F)
      (ι := ι) (C := MC) U₀ U₁).card), Nat.mul_comm (n := (R_star (A := A) (F := F) (ι := ι)
        (C := MC) U₀ U₁).card) (m := D.card)] at h_le_trans
    -- ↔ e * |R*| ≥ |D| * (|R*| - 1) (Q.E.D)
    have h_le_trans: n * #(R_star (A := A) (F := F) (ι := ι) (C := MC) (e := e) U₀ U₁)
      - e * #(R_star (A := A) (F := F) (ι := ι) (C := MC) (e := e) U₀ U₁)
      ≤ n * #(R_star (A := A) (F := F) (ι := ι) (C := MC) (e := e) U₀ U₁)
        - #D * #(R_star (A := A) (F := F) (ι := ι) (C := MC) (e := e) U₀ U₁) + #D := by
      conv_rhs =>
        rw [Nat.mul_comm n (#(R_star (A := A) (F := F) (ι := ι) (C := MC) (e := e) U₀ U₁))]
      exact h_le_trans
    -- conv_rhs at h_le_trans => enter [2]; rw [←Nat.mul_one #D]
    rw [Nat.sub_add_eq_sub_sub_rev (a := n * #(R_star (A := A) (F := F) (ι := ι) (C := MC) U₀ U₁))
      (b :=  #D * #(R_star (A := A) (F := F) (ι := ι) (C := MC) U₀ U₁)) (c := #D)
        (h1 := h_D_le_D_mul_R_star_card)
      (h2 := Nat.mul_le_mul_right (#(R_star (A := A) (F := F) (ι := ι) (C := MC) U₀ U₁))
        h_D_card_le_n)] at h_le_trans
    have h_le: #D * #(R_star (A := A) (F := F) (ι := ι) (C := MC) (e := e) U₀ U₁) - #D
      ≤ n * #(R_star (A := A) (F := F) (ι := ι) (C := MC) (e := e) U₀ U₁) := by
      apply Nat.sub_le_of_le_add; apply le_add_of_le_left;
      exact
        Nat.mul_le_mul_right (#(R_star (A := A) (F := F) (ι := ι) (C := MC) U₀ U₁)) h_D_card_le_n
    rw [Nat.sub_le_sub_iff_left (k := n * #(R_star (A := A) (F := F) (ι := ι) (C := MC) U₀ U₁))
      (h := h_le)] at h_le_trans
    exact h_le_trans
  have h_e_mul_Rstar_card_ge_Real: (e : ℝ) * (R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m)
    (e := e) U₀ U₁).card ≥ D.card * (R_star (A := A) (F := F) (ι := ι) (C := MC)
      (m := m) (e := e) U₀ U₁).card - D.card := by
    rw [←Nat.cast_mul, ←Nat.cast_mul, ←Nat.cast_sub (h := h_D_le_D_mul_R_star_card)]
    rw [ge_iff_le]
    rw [Nat.cast_le]
    exact h_e_mul_Rstar_card_ge
  -- `|D| ≤ e * (|R*| / (|R*| - 1))
  have h_D_card_le_e_mul_R_div_R_succ: D.card ≤ e *
    ((R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁).card : ℝ) /
    ((R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁).card - 1) := by
    rw [le_div_iff₀ (hc := by rw [sub_pos]; exact hR_star_card_gt1_Real)]
    rw [mul_sub, mul_one]
    exact h_e_mul_Rstar_card_ge_Real
  -- e * (|R*| / (|R*| - 1)) < e + 1 ↔ e * |R*| < e * |R*| - (e + 1) + |R*|
    -- ↔ 0 < |R*| - (e + 1) ↔ e + 1 < |R*|
  have h_e_mul_R_div_R_succ_lt: e * ((R_star (A := A) (F := F) (ι := ι) (C := MC)
    (m := m) (e := e) U₀ U₁).card : ℝ)
    / ((R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁).card - 1) < e + 1 := by
    exact e_mul_R_div_R_sub_1_lt_e_add_1_real (e := e) (R := (R_star (A := A)
      (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁).card) (hR_gt_e_add_1 := by omega)
  have h_D_card_le_e: D.card ≤ e := by
    apply Nat.le_of_lt_succ;
    have res := lt_of_le_of_lt (a := (#D : ℝ))
      (b := e * ((R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁).card : ℝ)
        / ((R_star (A := A) (F := F) (ι := ι) (C := MC) (m := m) (e := e) U₀ U₁).card - 1))
        (c := (e + 1 : ℝ)) (hab := h_D_card_le_e_mul_R_div_R_succ) (hbc := h_e_mul_R_div_R_succ_lt)
    rw [←Nat.cast_add_one, Nat.cast_lt] at res
    exact res
  dsimp only [D] at h_D_card_le_e
  exact (D_card_le_e_implies_interleaved_correlatedAgreement₂ (MC := MC)
    (m := m) (e := e) (ε := ε) U₀ U₁ hProximityGapAffineLines hR_star_card_gt_ε) (h_D_card_le_e)

/-- For each `r_{ϑ-1} ∈ 𝔽_q`, we abbreviate:
`p(r_{ϑ-1}) := Pr_{(r_0, ..., r_{ϑ-2}) ∈ 𝔽_q^{ϑ-1}} [`
  `d([⊗_{i=0}^{ϑ-2}(1-r_i, r_i)] · [(1-r_{ϑ-1}) · U₀ + r_{ϑ-1} · U₁], C) ≤ e]`
We define `R* := {r_{ϑ-1} ∈ 𝔽_q | p(r_{ϑ-1}) > (ϑ-1) · ε/q}`. We note that
`R*` is precisely the set of parameters `r_{ϑ-1} ∈ 𝔽_q` for which the half-length
matrix `(1-r_{ϑ-1}) · U₀ + r_{ϑ-1} · U₁` fulfills the inductive hypothesis (that is,
the hypothesis of Definition 2.3, with respect to the smaller list size parameter) -/
def R_star_tensor_filter (U₀ U₁ : (Fin (2 ^ m)) → Word A ι) (r_affine_combine : F) : Prop :=
  (Pr_{let r ← $ᵖ (Fin m → F)}[ -- This syntax only works with (A : Type 0)
    Δ₀(multilinearCombine_affineLineEvaluation (U₀ := U₀) (U₁ := U₁)
      (r := r) (r_affine_combine := r_affine_combine), MC) ≤ e
  ] > (m * ε: ℝ≥0) / (Fintype.card F : ℝ≥0))

open Classical in
def R_star_tensor (U₀ U₁ : (Fin (2 ^ m)) → Word A ι) : Finset F :=
  Finset.filter (fun r_affine_combine : F =>
    R_star_tensor_filter MC (m := m) (e := e) (ε := ε) U₀ U₁ r_affine_combine
  ) Finset.univ

omit [NoZeroDivisors F] [DecidableEq F] [Fintype A] [Module.Free F A] [Nontrivial ↥MC] in
open Classical in
/-- inductively to each such matrix, we conclude that,
for each `r_{ϑ-1} ∈ R*`, `d^{2^{ϑ-1}}((1-r_{ϑ-1}) · U₀ + r_{ϑ-1} · U₁, C^{2^{ϑ-1}}) ≤ e`
-/
lemma correlatedAgreement_of_mem_R_star_tensor
    {ϑ_pred : ℕ}
    (ih : δ_ε_multilinearCorrelatedAgreement_Nat (F := F) (A := A) (ι := ι) (C := MC) (ϑ := ϑ_pred)
      (e := e) (ε := ε))
    (u : Fin (2 ^ (ϑ_pred + 1)) → (Word A ι)) :
    -- This hypothesis comes from the main theorem's inductive step
    let ⟨U₀, U₁⟩ := splitHalfRowWiseInterleavedWords (ϑ := ϑ_pred) u
    ∀ (r : R_star_tensor MC (e := e) (ε := ε) U₀ U₁),
    jointProximityNat (u := affineLineEvaluation U₀ U₁ r.val) (e := e) (C := MC) := by
  -- simp only [Nat.add_one_sub_one, Subtype.forall]
  intro r
  apply ih
  -- ⊢ Pr_{ r ← Fin (ϑ_pred) → F}[ Δ₀(multilinearCombine Uᵣ (r := r), MC) ≤ e ] > (ϑ_pred * ε) / |𝔽|
  -- i.e. these r must satisfy (tensor-folding with the affine random combination)
    -- must be close to individual-row code MC
  set U₀ := (splitHalfRowWiseInterleavedWords (ϑ := ϑ_pred) u).1
  set U₁ := (splitHalfRowWiseInterleavedWords (ϑ := ϑ_pred) u).2
  unfold R_star_tensor at r
  -- Now, just state that the proof is `r.property`
  have hr:  R_star_tensor_filter MC U₀ U₁ ↑r :=
    (Finset.mem_filter (s := Finset.univ (α := F)) (a := r)
      (p := R_star_tensor_filter MC (e := e) (ε := ε) U₀ U₁).mp (coe_mem r)).2
  unfold R_star_tensor_filter at hr
  exact hr

def multilinearCombine_affineComb_split_last_close {ϑ : ℕ}
    (u : WordStack A (Fin (2 ^ (ϑ + 1))) ι) (e : ℕ) (r_last : F) (r_init : Fin (ϑ) → F) : Prop :=
    let U₀ := (splitHalfRowWiseInterleavedWords (ϑ := ϑ) u).1
    let U₁ := (splitHalfRowWiseInterleavedWords (ϑ := ϑ) u).2
    Δ₀(multilinearCombine (F := F) (A := A) (ι := ι)
      (affineLineEvaluation U₀ U₁ r_last) r_init, ↑MC) ≤ (e : ℕ∞)

omit [Nonempty ι] [NoZeroDivisors F] [Fintype A] [Module.Free F A] [Nontrivial ↥MC]
  [DecidableEq ι] [DecidableEq F] in
open Classical in
lemma prob_R_star_gt_threshold
    {ϑ : ℕ}
  (u : WordStack A (Fin (2 ^ (ϑ + 1))) ι) (e : ℕ)
  (hP_multilinearCombine_affine_close_gt :
    Pr_{ let r_last ← $ᵖ F;
         let r_init ← $ᵖ (Fin (ϑ) → F)}[multilinearCombine_affineComb_split_last_close
      (MC := MC) (u := u) (e := e) r_last r_init]
    > (((Nat.cast (R := ℝ≥0) (ϑ + 1)) * ε : ℝ≥0) / ((Fintype.card F : ℝ≥0) : ℝ≥0))) :
    let U₀ := (splitHalfRowWiseInterleavedWords (ϑ := ϑ) u).1
    let U₁ := (splitHalfRowWiseInterleavedWords (ϑ := ϑ) u).2
    let R_star_set := R_star_tensor MC (e := e) (ε := ε) U₀ U₁
  Pr_{ let r ← $ᵖ F }[ r ∈ R_star_set ] > (↑ε : ENNReal) / (Fintype.card F : ENNReal) := by
  -- 1. Setup abbreviations for clarity
  set U₀ := (splitHalfRowWiseInterleavedWords (ϑ := ϑ) u).1
  set U₁ := (splitHalfRowWiseInterleavedWords (ϑ := ϑ) u).2
  set R_star_set := R_star_tensor MC (m := ϑ) (e := e) (ε := ε) U₀ U₁
  let q := (Fintype.card F : ENNReal)
  let ε_enn := (ε : ENNReal)
  let ϑ_enn := (ϑ : ENNReal)
  have hq_ne_zero : q ≠ 0 := Ne.symm (NeZero.ne' q)
  --  ENNReal.natCast_ne_zero.mpr Fintype.card_ne_zero
  have hq_ne_top : q ≠ ⊤ := ENNReal.natCast_ne_top (Fintype.card F)
  have h_finite : (↑(Nat.cast (R := ℝ≥0) ϑ) * ↑ε / q) ≠ ⊤ :=
    ENNReal.div_ne_top (ENNReal.mul_ne_top (ENNReal.coe_ne_top) ENNReal.coe_ne_top)
      (Ne.symm (NeZero.ne' q))
  -- Define the thresholds from the paper
  let cur_false_witness_threshold := (((Nat.cast (R := ℝ≥0) (ϑ+1)) * ε: ℝ≥0) : ENNReal) / q
  let prev_false_witness_threshold := (((Nat.cast (R := ℝ≥0) ϑ) * ε: ℝ≥0) : ENNReal) / q
  let goal_threshold := (ε_enn / q)
  -- 2. Define the combined distribution and the two predicates
  let D : PMF (F × (Fin (ϑ) → F)) := do
    let r_last ← $ᵖ F
    let r_init ← $ᵖ (Fin (ϑ) → F)
    pure (r_last, r_init)
  set f := fun (r : F × (Fin ϑ → F)) =>
    multilinearCombine_affineComb_split_last_close (MC := MC) (u := u) (e := e) r.1 r.2
  set g := fun (r : F × (Fin ϑ → F)) => r.1 ∈ R_star_set
  -- 3. Rewrite the hypothesis `hP...` using the combined distribution `D`
  have h_D_eq_prod : D = $ᵖ (F × (Fin ϑ → F)) := by
    rw [←do_two_uniform_sampling_eq_uniform_prod]
  rw [Pr_multi_let_equiv_single_let] at hP_multilinearCombine_affine_close_gt
  -- `hP_f_gt` is the hypothesis `Pr[f] > cur_false_witness_threshold`
  have h_P_f_gt : Pr_{let r ← D}[f r] > cur_false_witness_threshold := by
    exact hP_multilinearCombine_affine_close_gt
  -- 4. Apply the Law of Total Probability: Pr[f] = Pr[f ∧ g] + Pr[f ∧ ¬g]
  have h_split : Pr_{let r ← D}[f r] =
    Pr_{let r ← D}[g r ∧ f r] + Pr_{let r ← D}[¬(g r) ∧ f r] := by
    apply Pr_add_split_by_complement
  -- 5. Bound the two terms on the RHS
  -- 5a. Pr[f ∧ g] ≤ Pr[g]
  have h_Pr_f_and_g_le_Pr_g : Pr_{let r ← D}[g r ∧ f r] ≤ Pr_{let r ← D}[g r] := by
    apply Pr_le_Pr_of_implies
    intro r h_imp; exact h_imp.1
  -- 5b. Pr[f ∧ ¬g] ≤ prev_false_witness_threshold (i.e., ϑε/q) (This is the "false positive" bound)
  -- Proof sketch: Pr_{let r ← D}[¬(g r) ∧ f r]
    -- = (1/q) * ∑' r_last, Pr_{r_init}[ r_last ∉ R_star_set ∧ f (r_init||r_last)]
  -- (1/q) * ∑' r_last, (if r_last ∉ R* then Pr_{r_init}[f(r_last, r_init)] else 0)
  -- ≤ (1/q) * ∑' r_last, (if r_last ∉ R* then (ϑ * ε/q) else 0)
  -- ≤ (1/q) * ∑' r_last, (ϑ * ε/q) = (1/q) * (ϑ * ε/q * q) = ϑ*ε/q (Q.E.D)
  have h_bound_not_g : Pr_{let r ← D}[¬(g r) ∧ f r] ≤ prev_false_witness_threshold := by
    dsimp only [D]
    rw [do_two_uniform_sampling_eq_uniform_prod (α := F) (β := (Fin ϑ → F))]
    rw [prob_split_uniform_sampling_of_prod]
    -- ⊢ Pr_{ x ← $ᵖ F; y ← $ᵖ (Fin ϑ → F)}[¬g (x, y) ∧ f (x, y)] ≤ prev_false_witness_threshold
    rw [prob_tsum_form_split_first (D := $ᵖ F) (D_rest :=
      fun r_last => (do let r_init ← $ᵖ (Fin ϑ → F); pure (¬(r_last ∈ R_star_set)
        ∧ f (r_last, r_init))))]
    conv_lhs =>
      simp only [PMF.uniformOfFintype_apply]; rw [ENNReal.tsum_mul_left]
      simp only [prob_const_and_prop_eq_ite]
    -- (1/q) * ∑' r_last, (if r_last ∉ R* then Pr_{r_init}[f(r_last, r_init)] else 0)
    have h_inner_le : ∀ (i: F), (if i ∉ R_star_set then
      Pr_{let r_init ← $ᵖ (Fin ϑ → F)}[f (i, r_init)] else 0)
        ≤ prev_false_witness_threshold := fun i => by
      by_cases hi_mem: i ∈ R_star_set
      · simp only [hi_mem, not_true_eq_false, ↓reduceIte, zero_le]
      · simp only [hi_mem, not_false_eq_true, ↓reduceIte]
        have h_i_mem_iff := Finset.mem_filter (s := Finset.univ (α := F)) (a := i)
          (p := fun r_last => R_star_tensor_filter MC (e := e) (ε := ε) U₀ U₁ r_last
      )
        simp only [R_star_set] at hi_mem
        have h_i_ne_mem_and_close := (Iff.not h_i_mem_iff).mp hi_mem
        have h_i_mem_univ: i ∈ Finset.univ (α := F) := by
          simp only [mem_univ]
        simp only [h_i_mem_univ, true_and] at h_i_ne_mem_and_close
        unfold R_star_tensor_filter at h_i_ne_mem_and_close
        simp only [gt_iff_lt, not_lt] at h_i_ne_mem_and_close
        exact h_i_ne_mem_and_close
    calc
      _ ≤ (((Fintype.card F): ENNReal)⁻¹ * ∑' (i : F), prev_false_witness_threshold) := by
        apply ENNReal.mul_le_mul_iff_right (h0 := ENNReal.inv_ne_zero.mpr hq_ne_top)
          (hinf := ENNReal.inv_ne_top.mpr hq_ne_zero).mpr
        apply ENNReal.tsum_le_tsum h_inner_le
      _ ≤ _ := by
        simp only [ENNReal.tsum_const, ENat.card_eq_coe_fintype_card, ENat.toENNReal_coe]
        rw [←mul_assoc]
        simp only [ne_eq, Nat.cast_eq_zero, Fintype.card_ne_zero, not_false_eq_true,
          ENNReal.natCast_ne_top, ENNReal.inv_mul_cancel, one_mul, le_refl]
  -- sorry
  -- 6. Chain the inequalities: `(ϑ+1)ε/q < Pr[f] ≤ Pr[g] + Pr[f ∧ ¬g] ≤ Pr[g] + ϑε/q`
  have h_total_lt_Pr_g_add_term : cur_false_witness_threshold
    < Pr_{let r ← D}[g r] + prev_false_witness_threshold := by
    calc cur_false_witness_threshold
      < Pr_{let r ← D}[f r] := h_P_f_gt
      _ = Pr_{let r ← D}[g r ∧ f r] + Pr_{let r ← D}[¬(g r) ∧ f r] := by rw [h_split]
      _ ≤ Pr_{let r ← D}[g r] + Pr_{let r ← D}[¬(g r) ∧ f r] := by
        gcongr
      _ ≤ Pr_{let r ← D}[g r] + prev_false_witness_threshold := by
        gcongr
      _ ≤ _ := by simp only [bind_pure_comp, le_refl]
  -- 7. Prove Pr[g] is equal to the goal probability (marginalization)
  have h_Pr_g_eq : Pr_{let r ← D}[g r] = Pr_{let r ← $ᵖ F}[ r ∈ R_star_set ] := by
    have h_D_rw : D = (do { let x ← $ᵖ F; let y ← $ᵖ (Fin ϑ → F); pure (x, y)}) := rfl
    rw [h_D_rw]
    rw [do_two_uniform_sampling_eq_uniform_prod]
    rw [prob_marginalization_first_of_prod]
  -- 8. Rearrange to get the final result
  -- We have: cur_false_witness_threshold < Pr[g] + prev_false_witness_threshold
  -- We want: goal_threshold < Pr[g]
  -- This is: cur_false_witness_threshold - prev_false_witness_threshold < Pr[g]
  rw [h_Pr_g_eq] at h_total_lt_Pr_g_add_term
  have h_lt_sub : cur_false_witness_threshold - prev_false_witness_threshold
    < Pr_{let r ← $ᵖ F}[r ∈ R_star_set] := by
    rw [ENNReal.sub_lt_iff_lt_right]
    · omega
    · exact h_finite
    · dsimp only [ENNReal.coe_mul, ENNReal.coe_natCast, prev_false_witness_threshold,
      cur_false_witness_threshold]
      apply ENNReal.div_le_div
      · by_cases h_ε_ne_zero : ε ≠ 0
        · let mul_right_le:= (ENNReal.mul_le_mul_iff_left (a := ϑ) (b := Nat.cast (R := ENNReal)
            (ϑ + 1)) (c := ε) (Nat.cast_ne_zero.mpr h_ε_ne_zero) (ENNReal.natCast_ne_top ε)).mpr
          apply mul_right_le
          simp only [Nat.cast_add, Nat.cast_one, self_le_add_right]
        · have h_ε_eq_zero : ε = 0 := by omega
          rw [h_ε_eq_zero]; simp only [CharP.cast_eq_zero, mul_zero, Nat.cast_add, Nat.cast_one,
            le_refl]
      · exact Preorder.le_refl q
  have h_sub_eq_goal : cur_false_witness_threshold - prev_false_witness_threshold
    = goal_threshold := by
    unfold cur_false_witness_threshold prev_false_witness_threshold goal_threshold
    simp only [Nat.cast_add, Nat.cast_one, ENNReal.coe_add, ENNReal.coe_one,
      ENNReal.coe_mul, ENNReal.coe_natCast, ε_enn]
    rw [add_mul]
    simp only [one_mul]
    rw [ENNReal.add_div]
    rw [add_comm, ENNReal.add_sub_cancel_right]
    exact ENNReal.div_ne_top (ENNReal.mul_ne_top (ENNReal.natCast_ne_top _) ENNReal.coe_ne_top)
      hq_ne_zero
  rw [h_sub_eq_goal] at h_lt_sub
  exact h_lt_sub

omit [DecidableEq F] [NoZeroDivisors F] [Fintype A] [Module.Free F A] [Nontrivial ↥MC] in
/- **Theorem 3.6 (Angeris-Evans-Roh AER24): Interleaved Affine Gaps -> Tensor Gaps**
If, for **every** interleaving factor `m ≥ 1`, the `m`-fold interleaved code `C^m`
features proximity gaps for affine lines with respect to parameters `e` and `ε`,
then the original code `C` also features tensor-style proximity gaps with respect
to the same parameters `e` and `ε`.
-/
theorem interleaved_affine_gaps_imply_tensor_gaps
    (hC_proximityGapAffineLines : e_ε_correlatedAgreementAffineLinesNat
      (F := F) (A := A) (ι := ι) (C := MC) (e := e) (ε := ε))
    (h_interleaved_gaps : ∀ m : ℕ, m ≥ 1 →
      e_ε_correlatedAgreementAffineLinesNat (F := F)
        (A := InterleavedSymbol A (Fin m)) (ι := ι) (C := MC ^⋈ (Fin m)) e ε) :
    ∀ (ϑ : ℕ), (hϑ_gt_0 : ϑ > 0) → δ_ε_multilinearCorrelatedAgreement_Nat (F := F) (A := A)
      (ι := ι) (C := MC) (ϑ := ϑ) (e := e) (ε := ε) := by
  classical
  intro ϑ
  induction ϑ with
  | zero =>
      intro h
      omega
  | succ n ih =>
      cases n with
      | zero =>
          simp only [zero_add, gt_iff_lt, zero_lt_one, ModuleCode, forall_const]
          intro u hprob
          let h_aff := multilinearCombine₁_eq_affineLineEvaluation (F := F) (u := u)
          simp_rw [h_aff] at hprob
          let h_single := prob_uniform_singleton_finFun_eq (F := F)
            (P := fun r => Δ₀(affineLineEvaluation (u 0) (u 1) r, MC) ≤ e)
          simp_rw [h_single, Nat.cast_one, ENNReal.coe_one, one_mul] at hprob
          have h := hC_proximityGapAffineLines (u 0) (u 1) hprob
          simp only [jointProximityNat₂, Fin.isValue] at h
          have hu : u = finMapTwoWords (u 0) (u 1) := by
            funext i
            match i with
            | 0 => rfl
            | 1 => rfl
          rw [hu.symm] at h
          exact h
      | succ k =>
          intro _ u hprob
          set U₀ : Fin (2 ^ (k + 1)) → Word A ι :=
            (splitHalfRowWiseInterleavedWords (ϑ := k + 1) u).1
          set U₁ : Fin (2 ^ (k + 1)) → Word A ι :=
            (splitHalfRowWiseInterleavedWords (ϑ := k + 1) u).2
          unfold jointProximityNat
          simp only
          have h_snoc : ∀ r : Fin (k + 1 + 1) → F,
              Fin.snoc (fun i : Fin (k + 1) => r i.castSucc)
                (r (Fin.last (k + 1))) = r := fun r => by
            funext i
            by_cases h : i = Fin.last (k + 1)
            · simp only [h, Fin.snoc_last]
            · have hv : i.val ≠ Fin.last (k + 1) := by omega
              rw [Fin.val_last] at hv
              have hi : i.val < k + 1 := by omega
              simp only [Fin.snoc, Fin.castSucc_castLT, cast_eq, dite_eq_ite,
                ite_eq_left_iff, not_lt]
              simp only [isEmpty_Prop, not_le, hi, IsEmpty.forall_iff]
          let P : F → (Fin (k + 1) → F) → Prop := fun r_last r_init =>
            Δ₀(multilinearCombine (u := u) (r := Fin.snoc r_init r_last), MC) ≤ e
          let h_split := prob_split_last_uniform_sampling_of_finFun
            (ϑ := k + 1) (F := F) (P := P)
          unfold P at h_split
          simp_rw [h_snoc] at h_split
          rw [h_split] at hprob
          have h_rec (r_init : Fin (k + 1) → F) (r_last : F) :
              multilinearCombine u (Fin.snoc r_init r_last) =
                multilinearCombine (affineLineEvaluation U₀ U₁ r_last) r_init := by
            rw [multilinearCombine_recursive_form]
            simp only [Fin.snoc_last, Fin.init_snoc]
            rfl
          simp_rw [h_rec] at hprob
          let R := R_star_tensor MC (m := k + 1) (e := e) (ε := ε) U₀ U₁
          have hR : Pr_{let r ← $ᵖ F}[r ∈ R] >
              (↑ε : ENNReal) / (Fintype.card F : ENNReal) := by
            exact prob_R_star_gt_threshold (MC := MC) (ε := ε) (ϑ := k + 1)
              (u := u) (e := e) hprob
          have hclose : ∀ r : R,
              jointProximityNat (u := affineLineEvaluation U₀ U₁ r.val)
                (e := e) (C := MC) := by
            intro r
            apply correlatedAgreement_of_mem_R_star_tensor
              (ih := fun u' => ih (by omega) u') (u := u)
          have hline :
              Pr_{let r ← $ᵖ F}[
                Δ₀(affineLineEvaluation
                    (u₀ := ⋈|(show WordStack A (Fin (2 ^ (k + 1))) ι from U₀))
                    (u₁ := ⋈|(show WordStack A (Fin (2 ^ (k + 1))) ι from U₁)) r,
                  MC ^⋈ (Fin (2 ^ (k + 1)))) ≤ e] >
                (↑ε : ENNReal) / (Fintype.card F : ENNReal) := by
            apply lt_of_le_of_lt' _ hR
            apply Pr_le_Pr_of_implies
            intro r hr
            have h := hclose ⟨r, hr⟩
            unfold jointProximityNat at h
            exact h
          have hfinal : jointProximityNat₂
              (u₀ := ⋈|(show WordStack A (Fin (2 ^ (k + 1))) ι from U₀))
              (u₁ := ⋈|(show WordStack A (Fin (2 ^ (k + 1))) ι from U₁))
              (e := e) (C := MC ^⋈ (Fin (2 ^ (k + 1)))) := by
            apply h_interleaved_gaps (2 ^ (k + 1)) Nat.one_le_two_pow
            exact hline
          exact CA_split_rowwise_implies_CA (MC : Set (Word A ι))
            (u := u) (e := e) hfinal

omit [DecidableEq ι] [Fintype F] [NoZeroDivisors F] [DecidableEq F] [Fintype A] [Module.Free F A]
  [Nontrivial ↥MC] in
lemma jointProximity₂_affineShift_implies_jointProximity₂ (u₀ u₁ : Word A ι) (δ : ℝ≥0) :
    jointProximity₂ (C := MC) (u₀ := u₀) (u₁ := u₁ - u₀) (δ := δ) →
    jointProximity₂ (C := MC) (u₀ := u₀) (u₁ := u₁) (δ := δ) := by
  classical
  intro h_shifted_jointProximity₂
  unfold jointProximity₂ at h_shifted_jointProximity₂ ⊢
  rw [←jointAgreement_iff_jointProximity] at h_shifted_jointProximity₂ ⊢
  unfold jointAgreement at h_shifted_jointProximity₂ ⊢
  rcases h_shifted_jointProximity₂ with ⟨S, hS_card_ge_1_minus_δ, v, hv_agree_u₀_u₁_on_S⟩
  use S
  have h_S_card_ge : ↑(#S) ≥ (1 - δ) * ↑(Fintype.card ι) := hS_card_ge_1_minus_δ
  use h_S_card_ge
  let v₀ := v 0
  let v₁ := v 1
  let v' : Fin 2 → Word A ι := fun i =>
    match i with
    | 0 => v₀
    | 1 => v₀ + v₁
  use v'
  intro i
  -- ⊢ v' i ∈ ↑MC ∧ S ⊆ {j | v' i j = finMapTwoWords u₀ u₁ i j}
  constructor
  · -- Show v' i ∈ MC
    match i with
    | 0 =>
      simp only [v', Fin.isValue]
      exact (hv_agree_u₀_u₁_on_S 0).1
    | 1 =>
      simp only [v', Fin.isValue]
      apply MC.add_mem
      · exact (hv_agree_u₀_u₁_on_S 0).1
      · exact (hv_agree_u₀_u₁_on_S 1).1
  · -- Show agreement on S
    match i with
    | 0 =>
      simp only [v', Fin.isValue]
      have h_subset := (hv_agree_u₀_u₁_on_S 0).2
      intro j hj
      specialize h_subset hj
      simp only [mem_filter, mem_univ, true_and] at h_subset
      simp only [mem_filter, mem_univ, true_and, finMapTwoWords]
      exact h_subset
    | 1 =>
      simp only [v', Fin.isValue]
      intro j hj
      simp only [mem_filter, mem_univ, true_and, finMapTwoWords]
      -- v' 1 j = v₀ j + v₁ j
      -- We know v₀ j = u₀ j and v₁ j = (u₁ - u₀) j
      have h_agree_0 := (hv_agree_u₀_u₁_on_S 0).2 hj
      have h_agree_1 := (hv_agree_u₀_u₁_on_S 1).2 hj
      simp only [mem_filter, mem_univ, true_and, finMapTwoWords, Fin.isValue] at h_agree_0 h_agree_1
      rw [Pi.add_apply]
      dsimp only [v₀, v₁]
      rw [h_agree_0, h_agree_1]
      simp only [Pi.sub_apply]
      abel

end MainResults

end
