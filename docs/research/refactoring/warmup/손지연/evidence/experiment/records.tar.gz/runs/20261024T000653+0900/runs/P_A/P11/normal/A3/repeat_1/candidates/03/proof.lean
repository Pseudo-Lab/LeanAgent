by
  simp only
  intro y
  set fiberMap := qMap_total_fiber 𝔽q β (i := ⟨i, by omega⟩) (steps := 1)
    (h_i_add_steps := by omega) (y := y)
  set x₀ := fiberMap 0
  set x₁ := fiberMap 1
  set P_i := intermediateEvaluationPoly 𝔽q β h_ℓ_add_R_rate (i := ⟨i, by omega⟩) coeffs
  set new_coeffs := fun j : Fin (2 ^ (ℓ - (i + 1))) =>
    (1 - r_chal) * coeffs ⟨j.val * 2, by
      apply mul_two_add_bit_lt_two_pow (c := ℓ - i) (a := j)
        (b := ℓ - (i + 1)) (i := 0)
      · exact j.isLt
      · omega
    ⟩ + r_chal * coeffs ⟨j.val * 2 + 1, by
      apply mul_two_add_bit_lt_two_pow (c := ℓ - i) (a := j)
        (b := ℓ - (i + 1)) (i := 1)
      · exact j.isLt
      · omega
    ⟩
  have h_eval_qMap_x₀ :
      (AdditiveNTT.qMap 𝔽q β ⟨i, by omega⟩).eval x₀.val = y := by
    have h := iteratedQuotientMap_k_eq_1_is_qMap 𝔽q β h_ℓ_add_R_rate i (by omega) x₀
    simp only [Subtype.ext_iff] at h
    rw [h.symm]
    have h_res := is_fiber_iff_generates_quotient_point 𝔽q β i (steps := 1) (by omega)
      (x := x₀) (y := y).mpr
        (by rw [pointToIterateQuotientIndex_qMap_total_fiber_eq_self])
    rw [h_res]
  have h_eval_qMap_x₁ :
      (AdditiveNTT.qMap 𝔽q β ⟨i, by omega⟩).eval x₁.val = y := by
    have h := iteratedQuotientMap_k_eq_1_is_qMap 𝔽q β h_ℓ_add_R_rate i (by omega) x₁
    simp only [Subtype.ext_iff] at h
    rw [h.symm]
    have h_res := is_fiber_iff_generates_quotient_point 𝔽q β i (steps := 1) (by omega)
      (x := x₁) (y := y).mpr
        (by rw [pointToIterateQuotientIndex_qMap_total_fiber_eq_self])
    rw [h_res]
  have h_fiber_diff : x₁.val - x₀.val = 1 := by
    let j₀ : Fin (ℓ + 𝓡 - i.val) := ⟨0, by omega⟩
    set basis_x := sDomain_basis 𝔽q β h_ℓ_add_R_rate ⟨i, by omega⟩ (by omega)
    set y_lifted : sDomain 𝔽q β h_ℓ_add_R_rate ⟨i, by omega⟩ :=
      sDomain.lift 𝔽q β h_ℓ_add_R_rate
        (i := ⟨i, by omega⟩) (j := ⟨i.val + 1, by omega⟩)
        (h_j := h_i_succ_lt) (h_le := by apply Fin.mk_le_mk.mpr; omega) y
    have hx₀ : x₀ = y_lifted := by
      simpa [x₀, fiberMap, basis_x, y_lifted, Fin2ToF2] using
        (qMap_total_fiber_one_level_eq 𝔽q β i (by omega) y (0 : Fin 2))
    have hx₁ : x₁ = basis_x j₀ + y_lifted := by
      simpa [x₁, fiberMap, basis_x, y_lifted, j₀, Fin2ToF2] using
        (qMap_total_fiber_one_level_eq 𝔽q β i (by omega) y (1 : Fin 2))
    rw [hx₁, hx₀]
    change (basis_x j₀ : L) + (y_lifted : L) - (y_lifted : L) = 1
    rw [add_sub_cancel_right]
    simp only [basis_x, j₀, get_sDomain_basis, add_zero]
    rw [normalizedWᵢ_eval_βᵢ_eq_1 𝔽q β]
  set P_i_plus_1 :=
    intermediateEvaluationPoly 𝔽q β h_ℓ_add_R_rate (i := ⟨i + 1, by omega⟩) new_coeffs
  set P₀ := evenRefinement 𝔽q β h_ℓ_add_R_rate i coeffs
  set P₁ := oddRefinement 𝔽q β h_ℓ_add_R_rate i coeffs
  have h_P_i_eval :=
    evaluation_poly_split_identity 𝔽q β h_ℓ_add_R_rate ⟨i, by omega⟩ coeffs
  have h_equation_39_x₀ :
      P_i.eval x₀.val = P₀.eval y.val + x₀.val * P₁.eval y.val := by
    simp only [h_P_i_eval, Fin.eta, Polynomial.eval_add, eval_comp,
      h_eval_qMap_x₀, Polynomial.eval_mul, Polynomial.eval_X, P_i, P₀, P₁]
  have h_equation_39_x₁ :
      P_i.eval x₁.val = P₀.eval y.val + x₁.val * P₁.eval y.val := by
    simp only [h_P_i_eval, Fin.eta, Polynomial.eval_add, eval_comp,
      h_eval_qMap_x₁, Polynomial.eval_mul, Polynomial.eval_X, P_i, P₀, P₁]
  set f_i := fun x : sDomain 𝔽q β h_ℓ_add_R_rate ⟨i, by omega⟩ =>
    P_i.eval (x.val : L)
  set f_i_plus_1 := fold (i := ⟨i, by omega⟩) (h_i := h_i_succ_lt)
    (f := f_i) (r_chal := r_chal)
  calc
    f_i_plus_1 y =
        f_i x₀ * ((1 - r_chal) * x₁.val - r_chal) +
        f_i x₁ * (r_chal - (1 - r_chal) * x₀.val) := rfl
    _ = P_i.eval x₀.val * ((1 - r_chal) * x₁.val - r_chal) +
        P_i.eval x₁.val * (r_chal - (1 - r_chal) * x₀.val) := by
          simp only [f_i]
    _ = (P₀.eval y.val + x₀.val * P₁.eval y.val) *
          ((1 - r_chal) * x₁.val - r_chal) +
        (P₀.eval y.val + x₁.val * P₁.eval y.val) *
          (r_chal - (1 - r_chal) * x₀.val) := by
          rw [h_equation_39_x₀, h_equation_39_x₁]
    _ = P₀.eval y.val * (1 - r_chal) + P₁.eval y.val * r_chal := by
          rw [h_fiber_diff]
          ring
    _ = P_i_plus_1.eval y.val := by
      simp only [P_i_plus_1, P₀, P₁, new_coeffs, evenRefinement, oddRefinement,
        intermediateEvaluationPoly]
      conv_lhs => enter [1]; rw [mul_comm, ← Polynomial.eval_C_mul]
      conv_lhs => enter [2]; rw [mul_comm, ← Polynomial.eval_C_mul]
      rw [← Polynomial.eval_add]
      congr
      simp_rw [mul_sum, ← Finset.sum_add_distrib]
      apply Finset.sum_congr rfl
      intro j hj
      have hj' : j.val < 2 ^ (ℓ - (i.val + 1)) := by
        simpa only [Nat.sub_sub] using j.isLt
      conv_lhs =>
        enter [1]
        rw [mul_comm (a := Polynomial.C (coeffs ⟨j.val * 2, by
          apply mul_two_add_bit_lt_two_pow (c := ℓ - i) (a := j)
            (b := ℓ - (i + 1)) (i := 0) hj'
          omega
        ⟩)), ← mul_assoc, mul_comm (a := Polynomial.C (1 - r_chal)), mul_assoc]
      conv_lhs =>
        enter [2]
        rw [mul_comm (a := Polynomial.C (coeffs ⟨j.val * 2 + 1, by
          apply mul_two_add_bit_lt_two_pow (c := ℓ - i) (a := j)
            (b := ℓ - (i + 1)) (i := 1) hj'
          omega
        ⟩)), ← mul_assoc, mul_comm (a := Polynomial.C r_chal), mul_assoc]
      conv_rhs => rw [mul_comm]
      rw [← mul_add]
      congr
      simp only [← Polynomial.C_mul, ← Polynomial.C_add]